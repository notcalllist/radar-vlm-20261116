# -*- coding: utf-8 -*-
"""把 nuScenes 帧转换为 Rex-Omni 微调所需的 TSV 格式。

输出（与官方 convert_json_data_to_tsv.py 一致）：
  images.tsv            每行: {image字节偏移}\t{base64 JPEG}
  annotations.tsv       每行: {image字节偏移}\t{annotation JSON}
  annotations.tsv.lineidx  每行: {annotation字节偏移}

annotation JSON（grounding）: {"boxes": [{"bbox": [x0,y0,x1,y1], "phrase": "car"}, ...]}

用法：
    .\.venv\Scripts\python.exe tools\nuscenes_to_tsv.py --limit 50 --out data/sft_tsv
"""
from __future__ import annotations

import argparse
import base64
import io
import json
import os
import sys
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import iter_frames, load_nuscenes  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--version", default="v1.0-mini")
    ap.add_argument("--channel", default="CAM_FRONT")
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--max-side", type=int, default=1280, help="图像最长边（控制 TSV 体积）")
    ap.add_argument("--out", default="data/sft_tsv")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, args.version)
    os.makedirs(args.out, exist_ok=True)
    img_tsv = open(os.path.join(args.out, "train.images.tsv"), "w", encoding="utf-8")
    ann_tsv = open(os.path.join(args.out, "train.annotations.tsv"), "w", encoding="utf-8")
    lineidx = open(os.path.join(args.out, "train.annotations.tsv.lineidx"), "w", encoding="utf-8")

    img_offset = 0
    ann_offset = 0
    n_samples = 0
    n_boxes = 0
    for frame in iter_frames(nusc, channel=args.channel, limit=args.limit):
        if not frame["boxes_2d"]:
            continue
        # 图像 -> base64 JPEG
        img = Image.open(frame["image_path"]).convert("RGB")
        if max(img.size) > args.max_side:
            scale = args.max_side / max(img.size)
            img = img.resize((int(img.width * scale), int(img.height * scale)), Image.BILINEAR)
            ratio_x = img.width / frame["image_size"][0]
            ratio_y = img.height / frame["image_size"][1]
            boxes = [
                {
                    "bbox": [
                        round(b["box_xyxy"][0] * ratio_x, 1),
                        round(b["box_xyxy"][1] * ratio_y, 1),
                        round(b["box_xyxy"][2] * ratio_x, 1),
                        round(b["box_xyxy"][3] * ratio_y, 1),
                    ],
                    "phrase": b["category"],
                }
                for b in frame["boxes_2d"]
            ]
        else:
            boxes = [
                {"bbox": b["box_xyxy"], "phrase": b["category"]} for b in frame["boxes_2d"]
            ]
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=92)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        img_line = f"{img_offset}\t{b64}\n"
        ann_json = json.dumps({"boxes": boxes}, ensure_ascii=False)
        ann_line = f"{img_offset}\t{ann_json}\n"
        lineidx.write(f"{ann_offset}\n")

        img_tsv.write(img_line)
        ann_tsv.write(ann_line)
        img_offset += len(img_line.encode("utf-8"))
        ann_offset += len(ann_line.encode("utf-8"))
        n_samples += 1
        n_boxes += len(boxes)

    img_tsv.close()
    ann_tsv.close()
    lineidx.close()
    print(f"samples: {n_samples}, boxes: {n_boxes}, out: {args.out}")
    print("files:")
    for f in ["train.images.tsv", "train.annotations.tsv", "train.annotations.tsv.lineidx"]:
        p = os.path.join(args.out, f)
        print(f"  {f}: {os.path.getsize(p) / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
