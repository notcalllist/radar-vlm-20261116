# 实验记录：VisDrone 数据与本地评测结论（2026-11-16）

## 1. 数据已就位

| 数据 | 规模 | 路径 |
|---|---|---|
| VisDrone2019-DET-val | 548 张图像 + 标注 | `data/visdrone/VisDrone2019-DET-val/` |
| VisDrone2019-DET-train | 6471 张图像 + 标注 | `data/visdrone/VisDrone2019-DET-train/` |
| 来源 | Ultralytics GitHub Releases 镜像（走代理下载） | - |

类别（10 类）：行人、人群、自行车、汽车、面包车、卡车、三轮车、棚三轮、公交、摩托车。
场景：中国 14 城，白天/黄昏/夜晚/雾天，密集与稀疏场景。

## 2. 本地零样本评测：不可行（已终止）

- 尝试：Rex-Omni 在 VisDrone 验证集图像上做零样本检测
- 现象：**单张图像推理超过 16 分钟未出结果**（另一次尝试超过 2 小时），GPU 100% 占用
- 原因分析：
  1. VisDrone 图像分辨率高（1360×765 ~ 2000×1500），视觉 token 多；
  2. 图像中目标密集（数十到数百个），模型输出序列长；
  3. 8GB 显存下模型部分层 offload 到 CPU，逐 token 速度极慢。
- 结论：**VisDrone 评测与 SFT 必须在 A100 上执行**（预计 2-5 秒/图 vs 本机的 15 分钟级）。

## 3. 对方案 A 的影响

- 数据准备已完成（下载、解压、类别映射脚本 `tools/visdrone_eval.py` 就绪）；
- 执行层面：VisDrone 零样本评测、俯视域 SFT 全部列入 A100 任务清单；
- 论文叙事：nuScenes（雷达融合验证）+ VisDrone（俯视域适应验证），需导师认可。

## 4. A100 任务清单（VisDrone 部分）

1. VisDrone val 前 50-100 张零样本评测 → `e7_visdrone_zero_shot.json`
2. VisDrone train 子集（~2000 张）转 TSV → 与 nuScenes TSV 合并/分阶段 SFT
3. SFT 后在 VisDrone val 上评测 → 俯视域适应效果
4. 产出对比表：nuScenes 零样本 0.078 vs VisDrone 零样本 vs VisDrone+SFT
