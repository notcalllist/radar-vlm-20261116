# A100 SFT 训练指南（Rex-Omni 微调）

> 目标：在 A100 上用 nuScenes 数据微调 Rex-Omni 3B（grounding 任务）
> 数据：`data/sft_tsv/`（150 帧、2091 框，已生成验证）
> 时间预估：单卡 A100 40GB，150 样本 × 1 epoch ≈ 10-20 分钟（含加载）

## 一、环境准备（一次性）

在 `~/radar-vlm/` 下：

```bash
cd third_party/Rex-Omni/finetuning
pip install -r requirements.txt
```

注意事项：
1. **flash-attn 编译**：需要 CUDA 工具链，安装可能 10-30 分钟；若编译失败，可先注释掉 requirements 中的 flash-attn，把脚本中相关 attention 设为 sdpa（train.py 目前默认 flash_attention_2，需改）。
2. **vllm**：只在推理/GRPO 需要；SFT 可以不安（requirements 里 vllm==0.8.2 与 torch 版本需匹配）。
3. **deepspeed/liger-kernel**：按 requirements 安装即可。
4. 若 deepspeed 冲突，把 `--deepspeed scripts/zero2.json` 去掉，用单卡普通训练（batch 1 + gradient checkpointing）。

## 二、启动 SFT

```bash
cd ~/radar-vlm
bash scripts/sft_nuscenes_a100.sh
```

脚本关键参数（已按单卡调小）：
- `GPUS_PER_NODE=1`、`batch=1`、`gradient_accumulation=8`
- `--tune_mm_vision False`（冻结视觉塔，省显存）
- `--config configs/sft_nuscenes.py`（指向我们的 TSV 数据）
- `--model_max_length 4096`

## 三、验证训练

```bash
# 查看日志（wandb 已关闭，日志在 output_dir）
tail -f work_dirs/sft_nuscenes/trainer_log.txt
# 显存监控
nvidia-smi -l 5
```

预期：loss 从 ~2 逐步下降；单卡约 3-5 it/s（视数据量）。

## 四、训练后评测

```bash
python project/tools/e4_rex_zero_shot.py \
  --model work_dirs/sft_nuscenes \
  --dataroot data/nuScenes --limit 50 \
  --out experiments/e5_sft_50frames.csv
```

（e4 脚本会加载指定模型路径；注意 SFT 输出是 checkpoint 目录，可能需转 HF 格式，见官方 README 的 convert 步骤。）

## 五、GRPO（第二阶段，可选）

官方 `scripts/grpo.sh` + `configs/grpo.py`，需要 vllm 与 verl 栈；奖励可在 `configs/grpo.py` 中改。建议 SFT 出结果后再评估是否值得投入 GRPO。

## 六、常见问题

| 问题 | 处理 |
|---|---|
| OOM | batch 1→0.5 不行；改 zero3 或减少 max_pixels |
| flash-attn 编译失败 | 跳过，用 sdpa（改 train.py 中 attn_implementation） |
| 数据路径错误 | 确认 `data/sft_tsv/` 三件套在 `~/radar-vlm/data/` 下 |
| 模型路径错误 | 确认 `models/Rex-Omni` 在 `~/radar-vlm/models/` 下 |
