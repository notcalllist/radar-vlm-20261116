# -*- coding: utf-8 -*-
"""点云解析与预处理工具（兼容 DroneRFc-MM 等 ASCII x,y,z 帧格式）。"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

PointArr = np.ndarray  # shape (N,3)


def parse_xyz_text(text: str) -> List[PointArr]:
    """解析以空行分隔的多帧点云文本；每行 'x,y,z' 或空白分隔。

    返回按帧排列的 (N,3) 数组列表。
    """
    frames: List[PointArr] = []
    cur: List[Tuple[float, float, float]] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            if cur:
                frames.append(np.asarray(cur, dtype=np.float32))
                cur = []
            continue
        parts = re.split(r"[,\s]+", line)
        if len(parts) < 3:
            continue
        try:
            x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
        except ValueError:
            continue
        cur.append((x, y, z))
    if cur:
        frames.append(np.asarray(cur, dtype=np.float32))
    return frames


def load_xyz_frames(path: str | Path) -> List[PointArr]:
    return parse_xyz_text(Path(path).read_text(encoding="utf-8", errors="ignore"))


def range_filter(
    points: PointArr,
    x_range: Tuple[float, float] = (-80.0, 80.0),
    y_range: Tuple[float, float] = (-80.0, 80.0),
    z_range: Tuple[float, float] = (-10.0, 30.0),
) -> PointArr:
    mask = (
        (points[:, 0] >= x_range[0])
        & (points[:, 0] <= x_range[1])
        & (points[:, 1] >= y_range[0])
        & (points[:, 1] <= y_range[1])
        & (points[:, 2] >= z_range[0])
        & (points[:, 2] <= z_range[1])
    )
    return points[mask]


def voxel_downsample(points: PointArr, voxel: float = 0.5) -> PointArr:
    """体素网格降采样：每个体素取点均值。"""
    keys = np.floor(points / voxel).astype(np.int64)
    uniq, inv = np.unique(keys, axis=0, return_inverse=True)
    sums = np.zeros((uniq.shape[0], 3), dtype=np.float64)
    counts = np.zeros(uniq.shape[0], dtype=np.float64)
    np.add.at(sums, inv, points)
    np.add.at(counts, inv, 1.0)
    return (sums / counts[:, None]).astype(np.float32)


def farthest_point_sample(points: PointArr, n: int) -> PointArr:
    """最远点采样（朴素实现，适合中小规模点云）。"""
    n = min(n, len(points))
    if n <= 0:
        return points[:0]
    selected = np.empty(n, dtype=np.int64)
    selected[0] = 0
    dist = np.full(len(points), np.inf, dtype=np.float64)
    for i in range(1, n):
        last = points[selected[i - 1]]
        d = np.sum((points - last) ** 2, axis=1)
        dist = np.minimum(dist, d)
        selected[i] = int(np.argmax(dist))
    return points[selected]


def normalize_points(points: PointArr) -> Tuple[PointArr, np.ndarray, np.ndarray]:
    """对 xyz 做 z-score 归一化；返回 (归一化点, mean, std)。"""
    mean = points.mean(axis=0).astype(np.float64)
    std = points.std(axis=0).astype(np.float64)
    std[std < 1e-6] = 1.0
    return ((points - mean) / std).astype(np.float32), mean, std


def frame_stats(frames: Sequence[PointArr]) -> Dict[str, float]:
    counts = np.array([len(f) for f in frames], dtype=np.float64)
    all_pts = np.concatenate(frames, axis=0) if frames else np.zeros((0, 3), np.float32)
    stats = {
        "n_frames": float(len(frames)),
        "total_points": float(all_pts.shape[0]),
        "points_mean": float(counts.mean()) if len(counts) else 0.0,
        "points_median": float(np.median(counts)) if len(counts) else 0.0,
        "points_min": float(counts.min()) if len(counts) else 0.0,
        "points_max": float(counts.max()) if len(counts) else 0.0,
    }
    if all_pts.shape[0]:
        stats["xyz_min"] = np.round(all_pts.min(axis=0), 2).tolist()
        stats["xyz_max"] = np.round(all_pts.max(axis=0), 2).tolist()
    return stats


if __name__ == "__main__":
    text = "0,0,0\n1,0,0\n0,1,0\n\n10,0,5\n11,0,5\n"
    frames = parse_xyz_text(text)
    assert len(frames) == 2
    assert frames[0].shape == (3, 3) and frames[1].shape == (2, 3)
    # range filter
    pts = np.array([[0, 0, 0], [100, 0, 0], [0, 0, 50]], dtype=np.float32)
    kept = range_filter(pts)
    assert kept.shape[0] == 1
    # voxel downsample
    pts2 = np.random.rand(200, 3).astype(np.float32) * 4
    down = voxel_downsample(pts2, 1.0)
    assert down.shape[0] <= 64
    # fps
    fps = farthest_point_sample(pts2, 16)
    assert fps.shape == (16, 3)
    # normalize
    norm, mean, std = normalize_points(pts2)
    assert norm.shape == pts2.shape and np.allclose(norm.mean(axis=0), 0, atol=1e-4)
    # stats
    st = frame_stats(frames)
    assert st["n_frames"] == 2 and st["total_points"] == 5
    print("pointcloud self-test: all passed; stats =", st)
