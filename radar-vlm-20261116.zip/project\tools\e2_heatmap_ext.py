# -*- coding: utf-8 -*-
"""E2 扩展：候选虚警率 + 按距离分层的覆盖率（CPU 可达）。

在 e2_heatmap 基础上补充：
- false_alarm_rois：与所有 GT IoU<0.3 的候选数；
- 距离分层覆盖率：GT 距离分桶（0-10/10-20/20-30/30-50/50+ m）的覆盖比例。

用法：
    python tools/e2_heatmap_ext.py --limit 200
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    build_sweep_index,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import evaluate_rois, generate_rois_heatmap, roi_covers_gt  # noqa: E402

BUCKETS = [(0, 10), (10, 20), (20, 30), (30, 50), (50, 200)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--accumulate", type=float, default=0.5)
    ap.add_argument("--cell", type=int, default=40)
    ap.add_argument("--min-pts", type=int, default=3)
    ap.add_argument("--min-cover", type=float, default=0.3)
    ap.add_argument("--out", default="experiments/e2_heatmap_ext.json")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    sweep_index = build_sweep_index(nusc)
    covs, fa_counts, n_rois = [], [], []
    buckets = {f"{a}-{b}m": {"n": 0, "hit": 0} for a, b in BUCKETS}

    for i, frame in enumerate(iter_frames(nusc, limit=args.limit)):
        if not frame["boxes_2d"]:
            continue
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        sample = nusc.get("sample", frame["sample_token"])
        ego = radar_sweeps_in_key_ego(nusc, sample, args.accumulate, sweep_index)
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
        cam_pts = _ego_to_cam(ego[:, :3], cam_cs) if len(ego) else np.zeros((0, 3))
        rois = generate_rois_heatmap(cam_pts, K, (W, H), cell=args.cell, min_pts=args.min_pts)
        ev = evaluate_rois(rois, frame["boxes_2d"], min_cover=args.min_cover)
        covs.append(ev["coverage"])
        fa_counts.append(ev["false_alarm_rois"])
        n_rois.append(len(rois))
        # 距离分层
        for gt in frame["boxes_2d"]:
            dist = gt.get("distance", 999)
            for a, b in BUCKETS:
                if a <= dist < b:
                    key = f"{a}-{b}m"
                    buckets[key]["n"] += 1
                    if any(roi_covers_gt(r["box_xyxy"], gt["box_xyxy"], args.min_cover) for r in rois):
                        buckets[key]["hit"] += 1
                    break

    summary = {
        "n_frames": len(covs),
        "coverage": round(float(np.mean(covs)), 3),
        "mean_rois": round(float(np.mean(n_rois)), 2),
        "mean_false_alarm_rois": round(float(np.mean(fa_counts)), 2),
        "false_alarm_rate": round(float(np.sum(fa_counts) / max(1e-9, np.sum(n_rois))), 3),
        "distance_buckets": {
            k: {
                "n_gt": v["n"],
                "coverage": round(v["hit"] / v["n"], 3) if v["n"] else None,
            }
            for k, v in buckets.items()
        },
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
