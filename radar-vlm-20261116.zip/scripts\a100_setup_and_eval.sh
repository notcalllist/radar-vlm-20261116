#!/usr/bin/env bash
# ===== A100 服务器：环境搭建 + 大样本评测（粘贴执行）=====
# 前提：已把以下目录传到服务器（ToDesk 文件传输）：
#   ~/radar-vlm/project/        （本地 project 目录，含 src/tools/experiments）
#   ~/radar-vlm/data/nuScenes/  （nuScenes mini，约 3.9GB 解压后 ~7GB）
#   ~/radar-vlm/models/Rex-Omni/（权重 7.75GB；或 AWQ 版 3.26GB 配合 vllm）
#
# 本脚本执行：
#   1) 建 venv + 安装依赖（torch cu124 / transformers / nuscenes-devkit / rex_omni）
#   2) 校验数据与权重
#   3) 跑 E2（含多帧累积热图）
#   4) 跑 E4 零样本（50 帧）
#   5) 跑 E4b 雷达提示 + E6 融合（50 帧，可分批）

set -e
WORK=~/radar-vlm
cd "$WORK"

echo "===== 1. Python 环境 ====="
if [ ! -d .venv ]; then python3 -m venv .venv; fi
source .venv/bin/activate
pip install -U pip -q
pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu124 -q
pip install transformers==4.51.3 accelerate==1.10.1 qwen_vl_utils==0.0.14 \
            nuscenes-devkit==1.2.0 pyquaternion pillow numpy matplotlib -q
pip install -e ./project --no-deps -q 2>/dev/null || true
# rex_omni 包（若已解压 Rex-Omni 仓库）
if [ -d Rex-Omni ]; then pip install -e ./Rex-Omni --no-deps -q; fi
python -c "import torch; print('torch:', torch.__version__, '| cuda:', torch.cuda.is_available())"

echo "===== 2. 校验数据/权重 ====="
ls -d data/nuScenes/v1.0-mini >/dev/null && echo "data OK"
ls -d models/Rex-Omni >/dev/null && echo "weights OK"

echo "===== 3. E2：雷达 RoI 质量（多帧累积+热图）====="
python project/tools/e2_heatmap.py --dataroot data/nuScenes --limit 50 --accumulate 0.3 \
  --out experiments/e2_heatmap_a100.json

echo "===== 4. E4：零样本评测（50 帧）====="
python project/tools/e4_rex_zero_shot.py --dataroot data/nuScenes --limit 50 \
  --out experiments/e4_zero_shot_a100.csv --vis-dir out/e4_vis_a100 \
  --max-pixels 1048576

echo "===== 5. E4b：雷达提示 + E6：融合（各 50 帧）====="
python project/tools/e4b_radar_hint.py --dataroot data/nuScenes --limit 50 \
  --out experiments/e4b_radar_hint_a100.csv --max-pixels 1048576

echo "===== DONE ====="
echo "结果在 experiments/ 和 out/ 下；建议把 JSON/CSV 拷回本地分析。"
