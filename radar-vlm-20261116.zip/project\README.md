# radar-vlm 项目工作区

> 硕士课题「基于雷达与视觉语言多模态融合的无人机目标感知方法研究」的实验代码与文档
> 2026-11-16 起建 ｜ 状态：骨架期

## 目录结构

```
project/
├── README.md
├── src/
│   ├── metrics.py        # 评估指标：IoU / 中心距 / 匹配 / AP / 重复率 / mAP
│   ├── pointcloud.py     # 点云解析（ASCII x,y,z 帧）、滤波、降采样、FPS、归一化、统计
│   └── vlm_protocol.py   # VLM 输出协议：prompt 构造、0-999 坐标 token、解析、NMS
├── data/                 # （待建）原始数据、标注、处理后样本
├── configs/              # （待建）实验配置
├── experiments/          # （待建）实验运行与结果
└── thesis/               # （待建）论文章节与图表
```

## 模块状态

| 模块 | 状态 | 说明 |
|---|---|---|
| metrics.py | ✅ 完成 | 单元自测通过；贪心匹配、VOC 面积插值 AP |
| pointcloud.py | ✅ 完成 | 兼容 DroneRFc-MM 的 x,y,z CSV 帧格式；自测通过 |
| vlm_protocol.py | ✅ 完成 | 对齐 Rex-Omni `<|box start|>` 序列格式；自测通过 |
| 数据加载器 | ⏳ 待数据 | 依赖数据集确定（A/B 口径） |
| 训练脚本 | ⏳ 待数据 | PointNet++/Sonata、Rex-Omni SFT/GRPO |
| 融合框架 | ⏳ 待模块 | 依赖雷达候选 + VLM 输出闭环 |

## 运行自测

```powershell
$py = "C:\Users\39854\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
cd project
& $py src\metrics.py
& $py src\pointcloud.py
& $py src\vlm_protocol.py
```

## 待确认事项（阻塞后续开发）

1. 题目口径 A（反无人机）/ B（无人机看地面）——决定数据集与全部实验
2. 数据集下载：DroneRFc-MM（SciDB）需本人注册下载
3. 实验室硬件/算力情况
4. 送审与答辩时间

## 相关文档

- `../冲刺计划草案_2026-11.md`：20 周计划、实验矩阵、论文章节重构方案
- `../项目调研备忘_数据与方法可行性.md`：数据集与开源方法调研
