# -*- coding: utf-8 -*-
"""E6：决策级融合评估（基于已保存的 VLM 预测 + 雷达 RoI）。

读取 out/e4b_preds/*.json（由 e4b_radar_hint.py 生成），对每帧：
1. 计算场景状态（图像亮度、模糊度、雷达密度）；
2. 调用 fusion.fuse 得到融合检测；
3. 对比 VLM-only / 雷达提示 / 决策级融合 的 AP50、Recall。

用法：
    python tools/e6_fusion_eval.py
"""
from __future__ import annotations

import argparse
import glob
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from fusion import fuse  # noqa: E402
from metrics import average_precision, precision_recall  # noqa: E402


def scene_state(image_path: str, n_radar_points: int):
    img = Image.open(image_path).convert("L")
    arr = np.asarray(img, dtype=np.float64) / 255.0
    brightness = float(arr.mean())
    small = arr[::4, ::4]  # 下采样加速
    lap_var = float(np.var(np.gradient(small)[0]) + np.var(np.gradient(small)[1]))
    blur = 1.0 - min(lap_var / 0.02, 1.0)  # 经验归一化
    density = min(n_radar_points / 1500.0, 1.0)
    return brightness, blur, density


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-conf", type=float, default=0.0, help="融合前过滤低置信雷达候选")
    ap.add_argument("--max-rois", type=int, default=0, help="融合前最多保留的候选数（0=不限）")
    ap.add_argument("--out", default="experiments/e6_fusion.json")
    args = ap.parse_args()

    files = sorted(glob.glob("out/e4b_preds/*.json"))
    if not files:
        print("no cached predictions; run tools/e4b_radar_hint.py first")
        return
    rows = []
    for fp in files:
        d = json.load(open(fp, encoding="utf-8"))
        gt = d["gt_boxes"]
        if not gt:
            continue
        W, H = 1600, 900
        try:
            from PIL import Image as _I
            W, H = _I.open(d["image_path"]).size
        except Exception:
            pass
        n_pts = sum(r.get("n_points", 0) for r in d["rois"]) * 3  # 近似雷达点数
        brightness, blur, density = scene_state(d["image_path"], n_pts)

        gb = [g["box_xyxy"] for g in gt]

        def ev(preds):
            if not preds:
                return 0.0, 0.0, 0.0
            pb = [p["box_px"] for p in preds]
            ps = [p.get("score", 1.0) for p in preds]
            return (
                round(average_precision(pb, ps, gb, 0.5), 3),
                round(precision_recall(pb, ps, gb, 0.5)[0], 3),
                round(precision_recall(pb, ps, gb, 0.5)[1], 3),
            )

        ap_full, p_full, r_full = ev(d["full_boxes"])
        ap_hint, p_hint, r_hint = ev(d["hint_boxes"])

        rois = [r for r in d["rois"] if r.get("conf", 0.0) >= args.min_conf]
        if args.max_rois > 0:
            rois = rois[: args.max_rois]
        fused = fuse(
            rois, d["full_boxes"],
            brightness=brightness, blur=blur, radar_density=density,
        )
        ap_f, p_f, r_f = ev(fused["detections"])
        rows.append(
            {
                "frame": d["frame"][:8],
                "gt": len(gt),
                "brightness": round(brightness, 2),
                "blur": round(blur, 2),
                "density": round(density, 2),
                "route": fused["route"],
                "full_ap50": ap_full, "full_rec": r_full,
                "hint_ap50": ap_hint, "hint_rec": r_hint,
                "fused_ap50": ap_f, "fused_rec": r_f,
            }
        )
        print(f"{d['frame'][:8]}: route={fused['route']:>6} | "
              f"full AP={ap_full} R={r_full} | hint AP={ap_hint} R={r_hint} | "
              f"fused AP={ap_f} R={r_f}")

    if not rows:
        print("no rows")
        return
    summary = {
        "n_frames": len(rows),
        "full_ap50": round(float(np.mean([r["full_ap50"] for r in rows])), 3),
        "full_recall": round(float(np.mean([r["full_rec"] for r in rows])), 3),
        "hint_ap50": round(float(np.mean([r["hint_ap50"] for r in rows])), 3),
        "hint_recall": round(float(np.mean([r["hint_rec"] for r in rows])), 3),
        "fused_ap50": round(float(np.mean([r["fused_ap50"] for r in rows])), 3),
        "fused_recall": round(float(np.mean([r["fused_rec"] for r in rows])), 3),
    }
    Path(args.out).write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
