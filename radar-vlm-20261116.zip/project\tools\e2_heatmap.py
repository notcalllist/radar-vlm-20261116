# -*- coding: utf-8 -*-
"""E2c：热图版 RoI 评估（单帧 vs 多帧累积）。

用法：
    python tools/e2_heatmap.py --limit 50 --accumulate 0.3
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    build_sweep_index,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import evaluate_rois, generate_rois_heatmap  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--accumulate", type=float, default=0.3)
    ap.add_argument("--cell", type=int, default=40)
    ap.add_argument("--min-pts", type=int, default=3)
    ap.add_argument("--min-cover", type=float, default=0.3)
    ap.add_argument("--out", default="experiments/e2_heatmap.json")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    sweep_index = build_sweep_index(nusc)
    covs, covs_single, n_rois, n_pts = [], [], [], []
    for i, frame in enumerate(iter_frames(nusc, limit=args.limit)):
        if not frame["boxes_2d"]:
            continue
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        sample = nusc.get("sample", frame["sample_token"])

        # 单帧
        rois1 = generate_rois_heatmap(frame["radar_points_cam"], K, (W, H),
                                      cell=args.cell, min_pts=args.min_pts)
        ev1 = evaluate_rois(rois1, frame["boxes_2d"], min_cover=args.min_cover)

        # 多帧
        ego_acc = radar_sweeps_in_key_ego(nusc, sample, args.accumulate, sweep_index)
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
        cam_pts = _ego_to_cam(ego_acc[:, :3], cam_cs) if len(ego_acc) else np.zeros((0, 3))
        rois2 = generate_rois_heatmap(cam_pts, K, (W, H),
                                      cell=args.cell, min_pts=args.min_pts)
        ev2 = evaluate_rois(rois2, frame["boxes_2d"], min_cover=args.min_cover)

        covs_single.append(ev1["coverage"])
        covs.append(ev2["coverage"])
        n_rois.append(len(rois2))
        n_pts.append(len(cam_pts))

    summary = {
        "n_frames": len(covs),
        "accumulate": args.accumulate,
        "cell": args.cell,
        "min_pts": args.min_pts,
        "min_cover": args.min_cover,
        "single_coverage": round(float(np.mean(covs_single)), 3),
        "multi_coverage": round(float(np.mean(covs)), 3),
        "avg_points": round(float(np.mean(n_pts)), 0),
        "avg_rois": round(float(np.mean(n_rois)), 2),
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
