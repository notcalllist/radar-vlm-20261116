# -*- coding: utf-8 -*-
"""E1：数据集统计（全集 340 帧）。

统计：帧数、类别分布、每帧 GT 数、目标距离分布、目标像素尺寸分布、雷达点数。

用法：
    python tools/e1_dataset_stats.py
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import iter_frames, load_nuscenes  # noqa: E402

DIST_BUCKETS = [(0, 10), (10, 20), (20, 30), (30, 50), (50, 80), (80, 500)]
SIZE_BUCKETS = [(0, 32), (32, 64), (64, 128), (128, 100000)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--out", default="experiments/e1_dataset_stats.json")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    cats = Counter()
    boxes_per_frame = []
    distances = []
    sizes = []
    radar_pts = []
    img_sizes = Counter()
    n_frames = 0

    for frame in iter_frames(nusc, limit=1000):
        n_frames += 1
        img_sizes[tuple(frame["image_size"])] += 1
        radar_pts.append(frame["n_radar_points"])
        boxes_per_frame.append(len(frame["boxes_2d"]))
        for b in frame["boxes_2d"]:
            cats[b["category"]] += 1
            distances.append(b.get("distance", 0))
            x0, y0, x1, y1 = b["box_xyxy"]
            sizes.append(max(x1 - x0, y1 - y0))

    def bucket_counts(values, buckets):
        out = {}
        for a, b in buckets:
            out[f"{a}-{b}"] = sum(1 for v in values if a <= v < b)
        return out

    summary = {
        "n_frames": n_frames,
        "categories": dict(cats.most_common()),
        "boxes_per_frame": {
            "mean": round(float(np.mean(boxes_per_frame)), 2),
            "max": int(np.max(boxes_per_frame)),
        },
        "distance_buckets": bucket_counts(distances, DIST_BUCKETS),
        "pixel_size_buckets": bucket_counts(sizes, SIZE_BUCKETS),
        "radar_points": {
            "mean": round(float(np.mean(radar_pts)), 1),
            "min": int(np.min(radar_pts)),
            "max": int(np.max(radar_pts)),
        },
        "image_sizes": {str(k): v for k, v in img_sizes.items()},
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
