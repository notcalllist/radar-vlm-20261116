# -*- coding: utf-8 -*-
"""VisDrone 零样本评测：Rex-Omni 在无人机俯视图像上的检测能力。

标注格式（VisDrone2019-DET）每行：
  bbox_left,bbox_top,bbox_width,bbox_height,score,category,truncation,occlusion
类别：1 pedestrian, 2 people, 3 bicycle, 4 car, 5 van, 6 truck, 7 tricycle,
      8 awning-tricycle, 9 bus, 10 motor

用法：
    python tools/visdrone_eval.py --limit 3
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from metrics import average_precision, precision_recall  # noqa: E402

CATEGORY_MAP = {
    1: "pedestrian",
    2: "pedestrian",
    3: "bicycle",
    4: "car",
    5: "car",
    6: "truck",
    7: None,   # tricycle 不评测
    8: None,
    9: "bus",
    10: "motorcycle",
}
REX_CATS = ["pedestrian", "bicycle", "car", "truck", "bus", "motorcycle"]


def parse_annotations(path: str):
    boxes = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split(",")
            if len(parts) < 6:
                continue
            x, y, w, h, score, cat = parts[:6]
            cat = int(float(cat))
            if cat not in CATEGORY_MAP or CATEGORY_MAP[cat] is None:
                continue
            x, y, w, h = float(x), float(y), float(w), float(h)
            if w <= 0 or h <= 0:
                continue
            boxes.append({"box_xyxy": [x, y, x + w, y + h], "category": CATEGORY_MAP[cat]})
    return boxes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data/visdrone")
    ap.add_argument("--split", default="val")
    ap.add_argument("--limit", type=int, default=3)
    ap.add_argument("--model", default="models/Rex-Omni")
    ap.add_argument("--max-pixels", type=int, default=495616)
    ap.add_argument("--max-tokens", type=int, default=256)
    ap.add_argument("--out", default="experiments/e7_visdrone_zero_shot.json")
    ap.add_argument("--vis-dir", default="out/visdrone_vis")
    args = ap.parse_args()

    img_dir = Path(args.root) / f"VisDrone2019-DET-{args.split}" / "images"
    ann_dir = Path(args.root) / f"VisDrone2019-DET-{args.split}" / "annotations"
    imgs = sorted(img_dir.glob("*.jpg"))[: args.limit]
    if not imgs:
        print("no images found at", img_dir)
        return

    from rex_infer import detect_boxes, load_rex, save_overlay

    rex = load_rex(args.model, max_tokens=args.max_tokens, max_pixels=args.max_pixels)
    os.makedirs(args.vis_dir, exist_ok=True)

    aps, precs, recs = [], [], []
    rows = []
    for img_path in imgs:
        ann_path = ann_dir / (img_path.stem + ".txt")
        gt = parse_annotations(str(ann_path)) if ann_path.exists() else []
        preds = detect_boxes(rex, str(img_path), REX_CATS)
        save_overlay(str(img_path), preds, str(Path(args.vis_dir) / img_path.name))
        if gt:
            pb = [p["box_px"] for p in preds]
            ps = [p["score"] for p in preds]
            gb = [g["box_xyxy"] for g in gt]
            ap50 = average_precision(pb, ps, gb, 0.5)
            p, r = precision_recall(pb, ps, gb, 0.5)
        else:
            ap50 = p = r = 0.0
        aps.append(ap50)
        precs.append(p)
        recs.append(r)
        rows.append({
            "image": img_path.name,
            "n_pred": len(preds),
            "n_gt": len(gt),
            "ap50": round(ap50, 3),
            "precision": round(p, 3),
            "recall": round(r, 3),
        })
        print(f"{img_path.name}: pred={len(preds)} gt={len(gt)} AP50={ap50:.3f} R={r:.3f}", flush=True)

    summary = {
        "split": args.split,
        "n_images": len(rows),
        "mean_ap50": round(float(np.mean(aps)), 3),
        "mean_precision": round(float(np.mean(precs)), 3),
        "mean_recall": round(float(np.mean(recs)), 3),
        "rows": rows,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
