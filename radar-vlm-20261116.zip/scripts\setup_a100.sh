# ===== A100 服务器初始化脚本（在服务器终端里粘贴执行）=====
# 前提：把安装包传上去：
#   1) Rex-Omni 代码：Rex-Omni-master.zip（本地 third_party/ 下）
#   2) 权重目录：Rex-Omni-AWQ（本地从 HF 下载后打包）
#   3) 可选：nuScenes 数据（v1.0-mini.tgz 或全量子集）
# 上传方式：ToDesk 文件传输，或服务器能连外网则直接 wget/git。
#
# 目录约定（按需修改）：
#   ~/radar-vlm/Rex-Omni/         代码
#   ~/radar-vlm/weights/Rex-Omni-AWQ/
#   ~/radar-vlm/data/nuScenes/

set -e
WORK=~/radar-vlm
mkdir -p "$WORK/weights" "$WORK/data/nuScenes"
cd "$WORK"

echo "===== 1. Check GPU & driver ====="
nvidia-smi || { echo "no GPU visible"; exit 1; }

echo "===== 2. Conda env ====="
if command -v conda >/dev/null 2>&1; then
  conda create -n rexomni python=3.10 -y || true
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate rexomni
else
  echo "conda not found, using python venv"
  python3 -m venv .venv && source .venv/bin/activate
fi

echo "===== 3. PyTorch (cu124 wheels; driver>=550) ====="
pip install -U pip
pip install torch==2.7.0 torchvision --index-url https://download.pytorch.org/whl/cu124

echo "===== 4. Rex-Omni ====="
if [ -d Rex-Omni ]; then
  echo "Rex-Omni dir exists, skip unzip"
else
  unzip -q Rex-Omni-master.zip
  mv Rex-Omni-master Rex-Omni
fi
cd Rex-Omni
pip install -r requirements.txt
pip install -v -e .
cd "$WORK"

echo "===== 5. Weights (Rex-Omni-AWQ 目录已上传) ====="
ls -lh weights/Rex-Omni-AWQ | head

echo "===== 6. Quick inference test ====="
cd Rex-Omni
python - <<'PY'
from PIL import Image
from rex_omni import RexOmniWrapper
rex = RexOmniWrapper(
    model_path="/root/radar-vlm/weights/Rex-Omni-AWQ",  # <<< 改成实际路径
    backend="vllm",
    quantization="awq",
    max_tokens=1024,
    temperature=0.0,
    top_p=0.05,
    top_k=1,
    repetition_penalty=1.05,
)
img = Image.open("tutorials/detection_example/test_images/cafe.jpg").convert("RGB")
res = rex.inference(images=img, task="detection", categories=["man", "woman", "cup"])
print(res[0]["raw_output"][:200])
print("OK")
PY

echo "===== DONE ====="
echo "环境路径: $(which python)"
echo "下一步: 执行训练脚本（见 scripts/train_sft.md）"
