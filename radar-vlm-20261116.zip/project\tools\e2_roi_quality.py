# -*- coding: utf-8 -*-
"""E2 实验：雷达候选区域（RoI）质量评估（BEV 聚类版）。

统计指标：RoI 覆盖率、Recall@K、虚警 RoI 数、每帧雷达点数、动态点数、GT 数。

用法：
    python tools/e2_roi_quality.py --dataroot data/nuScenes --limit 50 --out experiments/e2_roi_quality.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import evaluate_rois, generate_rois_bev  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--version", default="v1.0-mini")
    ap.add_argument("--channel", default="CAM_FRONT")
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--eps-m", type=float, default=1.2, help="BEV 聚类半径（米）")
    ap.add_argument("--min-samples", type=int, default=2)
    ap.add_argument("--no-dyn", action="store_true", help="关闭动态属性过滤")
    ap.add_argument("--accumulate", type=float, default=0.0, help="多帧累积窗口（秒），0=关闭")
    ap.add_argument("--min-cover", type=float, default=0.3, help="GT 被覆盖的面积比例阈值")
    ap.add_argument("--out", default="experiments/e2_roi_quality.csv")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, args.version)
    rows = []
    covs = []
    for i, frame in enumerate(iter_frames(nusc, channel=args.channel, limit=args.limit)):
        sample = nusc.get("sample", frame["sample_token"])
        if args.accumulate > 0:
            ego_acc = radar_sweeps_in_key_ego(nusc, sample, args.accumulate)
            if len(ego_acc):
                cam_sd = nusc.get("sample_data", sample["data"][args.channel])
                cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
                cam_pts = _ego_to_cam(ego_acc[:, :3], cam_cs)
                # 补 speed/dyn 两列（累积版无动态属性）
                ego_full = np.concatenate([ego_acc, np.zeros((len(ego_acc), 2))], axis=1)
                cam_full = np.concatenate([cam_pts, ego_acc[:, 3:4], np.zeros((len(ego_acc), 1))], axis=1)
            else:
                ego_full, cam_full = frame["radar_points_ego"], frame["radar_points_cam"]
        else:
            ego_full, cam_full = frame["radar_points_ego"], frame["radar_points_cam"]
        rois = generate_rois_bev(
            ego_full,
            cam_full,
            np.asarray(frame["K"]),
            tuple(frame["image_size"]),
            dyn_filter=not args.no_dyn and args.accumulate <= 0,
            eps_m=args.eps_m,
            min_samples=args.min_samples,
        )
        ev = evaluate_rois(rois, frame["boxes_2d"], min_cover=args.min_cover)
        rows.append(
            {
                "frame": f"{frame['scene']}_{frame['sample_token'][:8]}",
                "n_radar_points": int(len(ego_full)),
                "n_rois": len(rois),
                "n_gt": ev["n_gt"],
                "coverage": ev["coverage"],
                "recall_at_k": ev["recall_at_k"],
                "false_alarm_rois": ev["false_alarm_rois"],
            }
        )
        if ev["n_gt"] > 0:
            covs.append(ev["coverage"])
        if (i + 1) % 10 == 0:
            print(f"processed {i + 1} frames")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    summary = {
        "n_frames": len(rows),
        "accumulate_window": args.accumulate,
        "min_cover": args.min_cover,
        "mean_radar_points": round(float(np.mean([r["n_radar_points"] for r in rows])), 1),
        "mean_rois": round(float(np.mean([r["n_rois"] for r in rows])), 2),
        "mean_gt": round(float(np.mean([r["n_gt"] for r in rows])), 2),
        "mean_coverage": round(float(np.mean(covs)) if covs else 0.0, 3),
        "mean_false_alarm_rois": round(float(np.mean([r["false_alarm_rois"] for r in rows])), 2),
    }
    with open(Path(args.out).with_suffix(".json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
