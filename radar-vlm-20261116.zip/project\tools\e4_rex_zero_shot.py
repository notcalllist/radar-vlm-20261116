# -*- coding: utf-8 -*-
"""E4 实验：Rex-Omni 零样本检测评测（nuScenes）。

用法（数据就绪后）：
    .\.venv\Scripts\python.exe tools\e4_rex_zero_shot.py --limit 10 --out experiments/e4_zero_shot.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import iter_frames, load_nuscenes  # noqa: E402
from metrics import average_precision, precision_recall  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes/v1.0-mini")
    ap.add_argument("--version", default="v1.0-mini")
    ap.add_argument("--channel", default="CAM_FRONT")
    ap.add_argument("--limit", type=int, default=10)
    ap.add_argument("--model", default="models/Rex-Omni")
    ap.add_argument("--backend", default="transformers")
    ap.add_argument("--quantization", default=None)
    ap.add_argument("--max-pixels", type=int, default=704 * 704, help="图像最大像素（控制视觉 token 数）")
    ap.add_argument("--max-tokens", type=int, default=256)
    ap.add_argument("--out", default="experiments/e4_zero_shot.csv")
    ap.add_argument("--vis-dir", default="out/e4_vis")
    ap.add_argument("--mock", action="store_true", help="不加载模型，仅测试数据/评估管线")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, args.version)
    rex = None
    if not args.mock:
        from rex_infer import detect_boxes, load_rex, save_overlay

        rex = load_rex(
            args.model,
            backend=args.backend,
            quantization=args.quantization,
            max_tokens=args.max_tokens,
            max_pixels=args.max_pixels,
        )
        categories = ["car", "truck", "bus", "pedestrian", "motorcycle", "bicycle"]

    rows = []
    aps = []
    # 增量输出：预测 JSON 每帧保存，CSV 逐行追加（中断不丢数据）
    os.makedirs("out/e4_preds", exist_ok=True)
    csv_writer = None
    csv_file = None
    for i, frame in enumerate(iter_frames(nusc, channel=args.channel, limit=args.limit)):
        if args.mock:
            preds = []  # mock：空预测
        else:
            preds = detect_boxes(rex, frame["image_path"], categories)
            save_overlay(frame["image_path"], preds, os.path.join(args.vis_dir, f"frame_{i:04d}.jpg"))
            import json as _json
            with open(f"out/e4_preds/{frame['sample_token']}.json", "w", encoding="utf-8") as fh:
                _json.dump({"frame": frame["sample_token"], "preds": preds,
                            "gt": frame["boxes_2d"]}, fh, ensure_ascii=False)

        gt = frame["boxes_2d"]
        if gt:
            pb = [p["box_px"] for p in preds]
            ps = [p["score"] for p in preds]
            gb = [g["box_xyxy"] for g in gt]
            ap = average_precision(pb, ps, gb, 0.5)
            p, r = precision_recall(pb, ps, gb, 0.5)
            aps.append(ap)
        else:
            ap, p, r = 0.0, 0.0, 0.0
        rows.append(
            {
                "frame": f"{frame['scene']}_{frame['sample_token'][:8]}",
                "n_pred": len(preds),
                "n_gt": len(gt),
                "ap50": round(ap, 3),
                "precision": round(p, 3),
                "recall": round(r, 3),
            }
        )
        print(f"[{i + 1}/{args.limit}] frame {rows[-1]['frame']}: pred={len(preds)} gt={len(gt)} AP50={ap:.3f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    summary = {
        "n_frames": len(rows),
        "mean_ap50": round(float(np.mean(aps)) if aps else 0.0, 3),
        "mean_precision": round(float(np.mean([r["precision"] for r in rows])), 3),
        "mean_recall": round(float(np.mean([r["recall"] for r in rows])), 3),
    }
    with open(Path(args.out).with_suffix(".json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
