# -*- coding: utf-8 -*-
"""E2b：多帧累积窗口消融分析。

对每个窗口 w ∈ {0.1, 0.25, 0.5, 1.0} s：
  - 累积雷达点 → 热图 RoI → GT 覆盖率与 RoI 数量
输出：表格（论文参数分析用）。

用法：
    python tools/e2_window_sweep.py --limit 30
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes.nuscenes import NuScenes
from nuscenes.utils.data_classes import RadarPointCloud
from pyquaternion import Quaternion

from nuscenes_loader import (  # noqa: E402
    RADAR_CHANNELS,
    _ego_to_cam,
    _radar_to_ego,
    iter_frames,
    load_nuscenes,
)
from radar_roi import evaluate_rois, generate_rois_heatmap  # noqa: E402


def sweeps_in_window(nusc: NuScenes, sample: dict, t_lo: float, t_hi: float):
    """返回时间窗口内所有雷达 sweep 的 (ego 点, rcs)。"""
    key_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
    key_ep = nusc.get("ego_pose", key_sd["ego_pose_token"])
    qk = Quaternion(key_ep["rotation"])
    tk = np.asarray(key_ep["translation"], dtype=np.float64)
    pts_list, rcs_list = [], []
    for sd in nusc.sample_data:
        if sd["is_key_frame"] or sd["channel"] not in RADAR_CHANNELS:
            continue
        t = sd["timestamp"] / 1e6
        if t < t_lo or t > t_hi:
            continue
        cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
        ep = nusc.get("ego_pose", sd["ego_pose_token"])
        pc = RadarPointCloud.from_file(os.path.join(nusc.dataroot, sd["filename"]))
        pts = pc.points.T
        if pts.shape[0] == 0:
            continue
        pts_ego = _radar_to_ego(pts[:, :3], cs)
        q = Quaternion(ep["rotation"])
        tvec = np.asarray(ep["translation"], dtype=np.float64)
        global_pts = (q.rotation_matrix @ pts_ego.T).T + tvec
        p_key = (qk.inverse.rotation_matrix @ (global_pts - tk).T).T
        pts_list.append(p_key)
        rcs_list.append(pts[:, 5:6])
    if not pts_list:
        return np.zeros((0, 3)), np.zeros((0, 1))
    return np.concatenate(pts_list, axis=0), np.concatenate(rcs_list, axis=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=30)
    ap.add_argument("--windows", default="0.1,0.25,0.5,1.0")
    ap.add_argument("--cell", type=int, default=40)
    ap.add_argument("--min-pts", type=int, default=3)
    ap.add_argument("--min-cover", type=float, default=0.3)
    ap.add_argument("--out", default="experiments/e2_window_sweep.json")
    args = ap.parse_args()

    windows = [float(w) for w in args.windows.split(",")]
    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    frames = []
    for f in iter_frames(nusc, limit=args.limit):
        if f["boxes_2d"]:
            frames.append(f)
        if len(frames) >= args.limit:
            break

    results = {w: {"cov": [], "rois": [], "pts": []} for w in windows}
    for frame in frames:
        sample = nusc.get("sample", frame["sample_token"])
        t_key = sample["timestamp"] / 1e6
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
        for w in windows:
            ego_pts, rcs = sweeps_in_window(nusc, sample, t_key - w, t_key + w)
            cam_pts = _ego_to_cam(ego_pts, cam_cs) if len(ego_pts) else np.zeros((0, 3))
            rois = generate_rois_heatmap(cam_pts, K, (W, H), cell=args.cell, min_pts=args.min_pts)
            ev = evaluate_rois(rois, frame["boxes_2d"], min_cover=args.min_cover)
            results[w]["cov"].append(ev["coverage"])
            results[w]["rois"].append(len(rois))
            results[w]["pts"].append(len(cam_pts))

    summary = {}
    print(f"{'window(s)':>9} {'coverage':>8} {'rois':>6} {'points':>7}")
    for w in windows:
        cov = float(np.mean(results[w]["cov"]))
        rois = float(np.mean(results[w]["rois"]))
        pts = float(np.mean(results[w]["pts"]))
        summary[str(w)] = {"coverage": round(cov, 3), "rois": round(rois, 2), "points": round(pts, 0)}
        print(f"{w:>9} {cov:>8.3f} {rois:>6.2f} {pts:>7.0f}")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nsaved {args.out}")


if __name__ == "__main__":
    main()
