"""SFT 配置：nuScenes 雷达-VLM 候选数据（grounding 任务）。

路径约定（A100 服务器 ~/radar-vlm/）：
  data/sft_tsv/train.images.tsv
  data/sft_tsv/train.annotations.tsv
  data/sft_tsv/train.annotations.tsv.lineidx
  models/Rex-Omni

放置位置：third_party/Rex-Omni/finetuning/configs/sft_nuscenes.py
"""
from dataset import (
    ConcatDataset,
    DataCollatorForSupervisedDataset,
    GroundingTSVDataset,
)
from dataset.task_fns import GroundingTaskFn
from dataset.task_fns.task_prompts.grounding_task import (
    GROUNDING_SINGLE_REGION_STAGE_XYXY,
)

min_pixels = 16 * 28 * 28
max_pixels = 1280 * 28 * 28

model_name_or_path = "models/Rex-Omni"

grounding_data = dict(
    type=GroundingTSVDataset,
    img_tsv_file="data/sft_tsv/train.images.tsv",
    ann_tsv_file="data/sft_tsv/train.annotations.tsv",
    ann_lineidx_file="data/sft_tsv/train.annotations.tsv.lineidx",
    image_min_pixels=min_pixels,
    image_max_pixels=max_pixels,
    task_fn=dict(
        type=GroundingTaskFn,
        task_prompts=GROUNDING_SINGLE_REGION_STAGE_XYXY,
        image_min_pixels=min_pixels,
        image_max_pixels=max_pixels,
    ),
    dataset_name="nuscenes_grounding_data",
)

train_dataset = dict(
    type=ConcatDataset,
    datasets=[grounding_data],
)

data_collator = dict(type=DataCollatorForSupervisedDataset)
