# -*- coding: utf-8 -*-
"""E3 数据构建：雷达候选分类数据集（前景/背景）。

流程：
1. 每帧：多帧累积雷达(0.5s) → 热图 RoI（15 个）；
2. 每个 RoI：取投影落在 RoI 区域（1.2 倍扩张）内的雷达点，采样到 128 个，特征 (x,y,z,rcs)；
3. 标签：RoI 与任一 GT 的 IoU ≥ 0.3 → 正样本，否则负样本；
4. 保存 npz：points (N,128,4) float32, labels (N,), frame_ids。

用法：
    python tools/build_candidate_dataset.py --limit 40 --out data/e3_candidates.npz
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from metrics import iou  # noqa: E402
from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import generate_rois_heatmap  # noqa: E402

N_POINTS = 128


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=40)
    ap.add_argument("--window", type=float, default=0.5)
    ap.add_argument("--out", default="data/e3_candidates.npz")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    all_pts, all_labels, all_frames = [], [], []
    n_pos = n_neg = 0
    for frame in iter_frames(nusc, limit=args.limit):
        if not frame["boxes_2d"]:
            continue
        sample = nusc.get("sample", frame["sample_token"])
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])

        ego = radar_sweeps_in_key_ego(nusc, sample, args.window)
        if len(ego) == 0:
            continue
        cam_pts = _ego_to_cam(ego[:, :3], cam_cs)
        rois = generate_rois_heatmap(cam_pts, K, (W, H), cell=40, min_pts=3, max_rois=15)
        if not rois:
            continue
        # 投影所有点
        z = cam_pts[:, 2]
        vis = (z > 3) & (z < 80)
        pts, rcs = cam_pts[vis], ego[vis, 3]
        uvw = (K @ pts.T).T
        u = uvw[:, 0] / uvw[:, 2]
        v = uvw[:, 1] / uvw[:, 2]
        for r in rois:
            x0, y0, x1, y1 = r["box_xyxy"]
            bw, bh = x1 - x0, y1 - y0
            x0, y0 = x0 - 0.25 * bw, y0 - 0.25 * bh
            x1, y1 = x1 + 0.25 * bw, y1 + 0.25 * bh
            sel = (u >= x0) & (u <= x1) & (v >= y0) & (v <= y1)
            idx = np.where(sel)[0]
            if len(idx) == 0:
                continue
            if len(idx) > N_POINTS:
                idx = np.random.choice(idx, N_POINTS, replace=False)
            pts4 = np.concatenate([pts[idx], rcs[idx][:, None]], axis=1)  # (n,4)
            pad = np.zeros((N_POINTS - len(pts4), 4), dtype=np.float32)
            pts4 = np.concatenate([pts4, pad], axis=0)
            label = 1 if any(iou(r["box_xyxy"], g["box_xyxy"]) >= 0.3 for g in frame["boxes_2d"]) else 0
            all_pts.append(pts4.astype(np.float32))
            all_labels.append(label)
            all_frames.append(frame["sample_token"])
            n_pos += label
            n_neg += 1 - label

        print(f"frame {frame['sample_token'][:8]}: pos={n_pos} neg={n_neg}", flush=True)
        if n_pos + n_neg >= 2000:
            break

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    np.savez_compressed(
        args.out,
        points=np.stack(all_pts),
        labels=np.asarray(all_labels, dtype=np.int64),
        frames=np.asarray(all_frames),
    )
    print(f"saved {args.out}: {len(all_pts)} samples, pos={n_pos}, neg={n_neg}")


if __name__ == "__main__":
    main()
