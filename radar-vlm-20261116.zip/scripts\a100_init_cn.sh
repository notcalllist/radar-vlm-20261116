#!/usr/bin/env bash
# ============================================================
# A100 初始化（免翻墙版）：代码来自 Gitee，权重走 hf-mirror，数据直连
# 用法：bash scripts/a100_init_cn.sh
# 前提：本目录包含 project/ third_party/Rex-Omni/ scripts/ 等
# ============================================================
set -e
WORK=${WORK:-$(cd "$(dirname "$0")/.." && pwd)}
cd "$WORK"
export HF_ENDPOINT=https://hf-mirror.com
PIP_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple

echo "===== 0. GPU 检查 ====="
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader || { echo "找不到 GPU"; exit 1; }
echo "workdir: $WORK"

echo "===== 1. 数据目录 ====="
mkdir -p data/nuScenes data/visdrone models out

echo "===== 2. 下载 nuScenes mini (3.9GB, 直连) ====="
if [ ! -f data/nuScenes/v1.0-mini.tgz ]; then
  curl -L --retry 3 --max-time 7200 -o data/nuScenes/v1.0-mini.tgz \
    https://www.nuscenes.org/data/v1.0-mini.tgz
fi
if [ ! -d data/nuScenes/samples ]; then
  tar -xzf data/nuScenes/v1.0-mini.tgz -C data/nuScenes
fi
echo "nuScenes OK"

echo "===== 3. Python 环境（清华镜像）====="
if [ ! -d .venv ]; then python3 -m venv .venv; fi
source .venv/bin/activate
pip install -U pip -i $PIP_INDEX -q
pip install torch==2.7.0 torchvision==0.22.0 -i $PIP_INDEX -q || true
pip install transformers==4.51.3 accelerate==1.10.1 qwen_vl_utils==0.0.14 \
            nuscenes-devkit==1.2.0 pyquaternion pillow numpy matplotlib peft \
            huggingface_hub -i $PIP_INDEX -q || true

echo "--- 检查 torch CUDA ---"
if python - <<'PY'
import torch
print("torch", torch.__version__, "cuda", torch.cuda.is_available())
raise SystemExit(0 if torch.cuda.is_available() else 1)
PY
then
  echo "torch CUDA OK"
else
  echo "!! 当前 torch 不是 CUDA 版本，尝试从上海交大 PyTorch 镜像安装 cu126 版本"
  pip install torch==2.7.0 torchvision==0.22.0 \
    --index-url https://mirror.sjtu.edu.cn/pytorch-wheels/cu126 || true
  python -c "import torch; print('retry torch', torch.__version__, 'cuda', torch.cuda.is_available())"
fi

echo "===== 4. 下载 Rex-Omni 权重 (7.75GB, hf-mirror) ====="
python - <<'PY'
import os
from huggingface_hub import snapshot_download
if not os.path.exists("models/Rex-Omni/config.json"):
    snapshot_download("IDEA-Research/Rex-Omni", local_dir="models/Rex-Omni", max_workers=4)
    print("weights done")
else:
    print("weights exist, skip")
PY

echo "===== 5. 安装 rex_omni 包 ====="
pip install -e ./third_party/Rex-Omni --no-deps -q || true

echo "===== 6. 冒烟测试 ====="
python project/tools/visualize_radar_projection.py --dataroot data/nuScenes --out out/smoke_radar.png
CUDA_VISIBLE_DEVICES=0 python - <<'PY'
import sys, time, glob
sys.path.insert(0, "project/src")
from PIL import Image
from rex_infer import load_rex, detect_boxes
cands = sorted(glob.glob("data/nuScenes/samples/CAM_FRONT/*.jpg"))
img = Image.open(cands[0]).convert("RGB")
rex = load_rex("models/Rex-Omni", max_tokens=64, max_pixels=262144)
t = time.time()
boxes = detect_boxes(rex, img, ["car", "pedestrian"])
print(f"inference {time.time()-t:.1f}s, {len(boxes)} boxes")
PY

echo "===== DONE ====="
echo "环境: $WORK/.venv"
echo "下一步: 跑 E4 50 帧评测"
