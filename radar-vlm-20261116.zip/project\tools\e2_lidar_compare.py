# -*- coding: utf-8 -*-
"""E2c：雷达 vs 激光雷达候选覆盖率对比（100 帧）。

雷达：多帧累积(0.5s) + 密度热图；
激光雷达：单帧 LIDAR_TOP + 同一套投影/热图流程。

用法：
    python tools/e2_lidar_compare.py --limit 100
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
from nuscenes.utils.data_classes import LidarPointCloud

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    _radar_to_ego,
    build_sweep_index,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import evaluate_rois, generate_rois_heatmap  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=100)
    ap.add_argument("--window", type=float, default=0.5)
    ap.add_argument("--cell", type=int, default=40)
    ap.add_argument("--min-pts", type=int, default=3)
    ap.add_argument("--min-cover", type=float, default=0.3)
    ap.add_argument("--out", default="experiments/e2_lidar_compare.json")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    sweep_index = build_sweep_index(nusc)
    res = {"radar": [], "lidar": []}
    n_pts_radar, n_pts_lidar = [], []

    for i, frame in enumerate(iter_frames(nusc, limit=args.limit)):
        if not frame["boxes_2d"]:
            continue
        sample = nusc.get("sample", frame["sample_token"])
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])

        # 雷达
        ego_radar = radar_sweeps_in_key_ego(nusc, sample, args.window, sweep_index)
        cam_radar = _ego_to_cam(ego_radar[:, :3], cam_cs) if len(ego_radar) else np.zeros((0, 3))
        rois_r = generate_rois_heatmap(cam_radar, K, (W, H), cell=args.cell, min_pts=args.min_pts)
        ev_r = evaluate_rois(rois_r, frame["boxes_2d"], min_cover=args.min_cover)
        res["radar"].append(ev_r["coverage"])
        n_pts_radar.append(len(cam_radar))

        # 激光雷达
        lidar_sd = nusc.get("sample_data", sample["data"]["LIDAR_TOP"])
        lidar_cs = nusc.get("calibrated_sensor", lidar_sd["calibrated_sensor_token"])
        pc = LidarPointCloud.from_file(os.path.join(nusc.dataroot, lidar_sd["filename"]))
        pts = pc.points.T[:, :3]
        ego_lidar = _radar_to_ego(pts, lidar_cs)
        cam_lidar = _ego_to_cam(ego_lidar, cam_cs)
        rois_l = generate_rois_heatmap(cam_lidar, K, (W, H), cell=args.cell, min_pts=args.min_pts)
        ev_l = evaluate_rois(rois_l, frame["boxes_2d"], min_cover=args.min_cover)
        res["lidar"].append(ev_l["coverage"])
        n_pts_lidar.append(len(cam_lidar))

        if (i + 1) % 25 == 0:
            print(f"{i+1} frames done", flush=True)

    summary = {
        "n_frames": len(res["radar"]),
        "radar_coverage": round(float(np.mean(res["radar"])), 3),
        "lidar_coverage": round(float(np.mean(res["lidar"])), 3),
        "radar_points": round(float(np.mean(n_pts_radar)), 0),
        "lidar_points": round(float(np.mean(n_pts_lidar)), 0),
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
