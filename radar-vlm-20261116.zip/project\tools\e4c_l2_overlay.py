# -*- coding: utf-8 -*-
"""E4c：L2 视觉级融合实验——雷达点云叠加图作为 VLM 视觉输入。

做法：多帧累积雷达 → 投影 → 在图像上绘制距离着色点云 → 送 Rex-Omni 检测，
与全图零样本（E4 缓存）对比 AP50 / Recall。

用法：
    python tools/e4c_l2_overlay.py --limit 3
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from metrics import average_precision, precision_recall, iou  # noqa: E402
from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from rex_infer import detect_boxes, load_rex  # noqa: E402

CATEGORIES = ["car", "truck", "bus", "pedestrian", "motorcycle", "bicycle"]


def render_overlay(image_path: str, cam_pts: np.ndarray, K: np.ndarray, out_path: str) -> str:
    img = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    W, H = img.size
    z = cam_pts[:, 2]
    vis = (z > 3) & (z < 80) & (np.abs(cam_pts[:, 0]) < z * 2.5)
    pts = cam_pts[vis]
    if len(pts):
        uvw = (K @ pts.T).T
        u = uvw[:, 0] / uvw[:, 2]
        v = uvw[:, 1] / uvw[:, 2]
        m = (u >= 0) & (u < W) & (v >= 0) & (v < H)
        u, v, d = u[m], v[m], z[vis][m]
        for uu, vv, dd in zip(u, v, d):
            r = int(255 * np.clip(1 - dd / 60.0, 0, 1))
            b = 255 - r
            draw.ellipse([uu - 2, vv - 2, uu + 2, vv + 2], fill=(r, 40, b))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    img.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=3)
    ap.add_argument("--window", type=float, default=0.5)
    ap.add_argument("--max-pixels", type=int, default=495616)
    ap.add_argument("--max-tokens", type=int, default=256)
    ap.add_argument("--out", default="experiments/e4c_l2_overlay.csv")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    rex = load_rex("models/Rex-Omni", backend="transformers",
                   max_tokens=args.max_tokens, max_pixels=args.max_pixels)

    frames = []
    for f in iter_frames(nusc, limit=args.limit * 3):
        if f["boxes_2d"]:
            frames.append(f)
        if len(frames) >= args.limit:
            break

    rows = []
    for f in frames:
        sample = nusc.get("sample", f["sample_token"])
        K = np.asarray(f["K"])
        ego = radar_sweeps_in_key_ego(nusc, sample, args.window)
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
        cam_pts = _ego_to_cam(ego[:, :3], cam_cs) if len(ego) else np.zeros((0, 3))

        overlay_path = f"out/e4c_overlay/{f['sample_token']}.jpg"
        render_overlay(f["image_path"], cam_pts, K, overlay_path)

        preds = detect_boxes(rex, overlay_path, CATEGORIES)
        # 与 E4 缓存的全图预测对比（若存在）
        full_preds = []
        cache = f"out/e4b_preds/{f['sample_token']}.json"
        if os.path.exists(cache):
            full_preds = json.load(open(cache, encoding="utf-8"))["full_boxes"]

        gb = [g["box_xyxy"] for g in f["boxes_2d"]]

        def ev(ps):
            if not ps:
                return 0.0, 0.0, 0.0
            pb = [p["box_px"] for p in ps]
            sc = [p.get("score", 1.0) for p in ps]
            return (round(average_precision(pb, sc, gb, 0.5), 3),
                    round(precision_recall(pb, sc, gb, 0.5)[0], 3),
                    round(precision_recall(pb, sc, gb, 0.5)[1], 3))

        ap_o, p_o, r_o = ev(preds)
        ap_f, p_f, r_f = ev(full_preds)
        rows.append({
            "frame": f["sample_token"][:8], "n_gt": len(f["boxes_2d"]),
            "overlay_pred": len(preds), "overlay_ap50": ap_o, "overlay_recall": r_o,
            "full_pred": len(full_preds), "full_ap50": ap_f, "full_recall": r_f,
        })
        print(f"{f['sample_token'][:8]} gt={len(f['boxes_2d'])} | "
              f"overlay pred={len(preds)} AP={ap_o} R={r_o} | "
              f"full AP={ap_f} R={r_f}", flush=True)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    summary = {
        "n_frames": len(rows),
        "overlay_ap50": round(float(np.mean([r["overlay_ap50"] for r in rows])), 3),
        "overlay_recall": round(float(np.mean([r["overlay_recall"] for r in rows])), 3),
        "full_ap50": round(float(np.mean([r["full_ap50"] for r in rows])), 3),
        "full_recall": round(float(np.mean([r["full_recall"] for r in rows])), 3),
    }
    with open(Path(args.out).with_suffix(".json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
