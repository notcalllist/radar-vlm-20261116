# -*- coding: utf-8 -*-
"""nuScenes 数据加载器：雷达点云 + 相机图像 + 3D 标注 + 标定。

用途：为“雷达-视觉融合”实验提供统一帧结构。
依赖：nuscenes-devkit, pyquaternion, numpy（已装入 .venv）。
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
from nuscenes.nuscenes import NuScenes
from nuscenes.utils.data_classes import Box, RadarPointCloud
from pyquaternion import Quaternion

RADAR_CHANNELS = [
    "RADAR_FRONT",
    "RADAR_FRONT_LEFT",
    "RADAR_FRONT_RIGHT",
    "RADAR_BACK_LEFT",
    "RADAR_BACK_RIGHT",
]

# 需要检测/定位的类别（与 VLM prompt 类别对齐）
KEEP_CATEGORIES = {
    "human.pedestrian.adult",
    "human.pedestrian.child",
    "human.pedestrian.construction_worker",
    "human.pedestrian.police_officer",
    "vehicle.car",
    "vehicle.truck",
    "vehicle.bus.bendy",
    "vehicle.bus.rigid",
    "vehicle.motorcycle",
    "vehicle.bicycle",
}
CATEGORY_MAP = {
    "human.pedestrian.adult": "pedestrian",
    "human.pedestrian.child": "pedestrian",
    "human.pedestrian.construction_worker": "pedestrian",
    "human.pedestrian.police_officer": "pedestrian",
    "vehicle.car": "car",
    "vehicle.truck": "truck",
    "vehicle.bus.bendy": "bus",
    "vehicle.bus.rigid": "bus",
    "vehicle.motorcycle": "motorcycle",
    "vehicle.bicycle": "bicycle",
}


def load_nuscenes(dataroot: str, version: str = "v1.0-mini") -> NuScenes:
    return NuScenes(version=version, dataroot=dataroot, verbose=False)


def _ego_to_cam(points_ego: np.ndarray, cam_cs: dict) -> np.ndarray:
    q = Quaternion(cam_cs["rotation"])
    t = np.asarray(cam_cs["translation"], dtype=np.float64)
    return (q.inverse.rotation_matrix @ (points_ego - t).T).T


def _radar_to_ego(points_radar: np.ndarray, radar_cs: dict) -> np.ndarray:
    q = Quaternion(radar_cs["rotation"])
    t = np.asarray(radar_cs["translation"], dtype=np.float64)
    return (q.rotation_matrix @ points_radar.T).T + t


def _global_to_cam(points_global: np.ndarray, cam_cs: dict, cam_ep: dict) -> np.ndarray:
    q_e = Quaternion(cam_ep["rotation"])
    t_e = np.asarray(cam_ep["translation"], dtype=np.float64)
    p_ego = (q_e.inverse.rotation_matrix @ (points_global - t_e).T).T
    return _ego_to_cam(p_ego, cam_cs)


def project_to_image(points_cam: np.ndarray, K: np.ndarray) -> np.ndarray:
    """相机坐标 -> 像素坐标。返回 (N,3): u, v, depth。"""
    z = points_cam[:, 2]
    uvw = (K @ points_cam.T).T
    u = uvw[:, 0] / np.where(np.abs(uvw[:, 2]) < 1e-9, 1e-9, uvw[:, 2])
    v = uvw[:, 1] / np.where(np.abs(uvw[:, 2]) < 1e-9, 1e-9, uvw[:, 2])
    return np.stack([u, v, z], axis=1)


def get_frame(nusc: NuScenes, sample: dict, channel: str = "CAM_FRONT") -> Dict:
    """从 sample 提取统一帧结构（图像、雷达点云、2D 框、标定）。"""
    # ---- 相机 ----
    cam_sd = nusc.get("sample_data", sample["data"][channel])
    cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
    cam_ep = nusc.get("ego_pose", cam_sd["ego_pose_token"])
    K = np.asarray(cam_cs["camera_intrinsic"], dtype=np.float64)
    image_path = os.path.join(nusc.dataroot, cam_sd["filename"])
    W, H = cam_sd["width"], cam_sd["height"]

    # ---- 雷达点云（5 路拼接） ----
    all_pts_cam: List[np.ndarray] = []
    all_pts_ego: List[np.ndarray] = []
    for ch in RADAR_CHANNELS:
        if ch not in sample["data"]:
            continue
        sd = nusc.get("sample_data", sample["data"][ch])
        cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
        pc = RadarPointCloud.from_file(os.path.join(nusc.dataroot, sd["filename"]))
        pts = pc.points.T  # (N,18)
        if pts.shape[0] == 0:
            continue
        pts_ego = _radar_to_ego(pts[:, :3], cs)
        pts_cam = _ego_to_cam(pts_ego, cam_cs)
        # 相机系: x,y,z,rcs,speed
        feat_cam = np.concatenate(
            [pts_cam, pts[:, 5:6], pts[:, 6:8].sum(axis=1, keepdims=True)], axis=1
        )
        # ego 系: x,y,z,rcs,speed,dyn_prop
        feat_ego = np.concatenate(
            [
                pts_ego,
                pts[:, 5:6],
                pts[:, 6:8].sum(axis=1, keepdims=True),
                pts[:, 3:4],
            ],
            axis=1,
        )
        all_pts_cam.append(feat_cam)
        all_pts_ego.append(feat_ego)

    radar_pts = np.concatenate(all_pts_cam, axis=0) if all_pts_cam else np.zeros((0, 5), np.float64)
    radar_pts_ego = np.concatenate(all_pts_ego, axis=0) if all_pts_ego else np.zeros((0, 6), np.float64)

    # ---- 标注（3D 框 -> 2D 框） ----
    boxes_2d: List[Dict] = []
    for ann_token in sample.get("anns", []):
        ann = nusc.get("sample_annotation", ann_token)
        cat = ann.get("category_name", "")
        if cat not in KEEP_CATEGORIES:
            continue
        box = nusc.get_box(ann_token)
        rot = Quaternion(box.orientation)
        corners_local = np.array(
            [
                [dx, dy, dz]
                for dx in (-box.wlh[0] / 2, box.wlh[0] / 2)
                for dy in (-box.wlh[1] / 2, box.wlh[1] / 2)
                for dz in (-box.wlh[2] / 2, box.wlh[2] / 2)
            ]
        )
        corners = (rot.rotation_matrix @ corners_local.T).T + np.asarray(box.center)
        cam_pts = _global_to_cam(corners, cam_cs, cam_ep)
        proj = project_to_image(cam_pts, K)
        depth = float(cam_pts[:, 2].mean())
        visible = (cam_pts[:, 2] > 0.5) & (proj[:, 0] > 0) & (proj[:, 0] < W) & (proj[:, 1] > 0) & (proj[:, 1] < H)
        if visible.sum() < 4 or depth <= 0.5:
            continue
        u = proj[visible, 0]
        v = proj[visible, 1]
        x0, y0, x1, y1 = float(u.min()), float(v.min()), float(u.max()), float(v.max())
        if (x1 - x0) < 4 or (y1 - y0) < 4:
            continue
        dist = float(np.linalg.norm(np.asarray(box.center) - np.asarray(cam_ep["translation"])))
        boxes_2d.append(
            {
                "category": CATEGORY_MAP.get(cat, cat),
                "category_raw": cat,
                "box_xyxy": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)],
                "depth": round(depth, 2),
                "distance": round(dist, 2),
            }
        )

    scene = nusc.get("scene", sample["scene_token"])
    return {
        "sample_token": sample["token"],
        "scene": scene["name"],
        "timestamp": sample["timestamp"],
        "image_path": image_path,
        "image_size": [W, H],
        "K": K.tolist(),
        "radar_points_cam": radar_pts,  # (N,5): x,y,z,rcs,speed
        "radar_points_ego": radar_pts_ego,  # (N,6): x,y,z,rcs,speed,dyn_prop
        "boxes_2d": boxes_2d,
        "n_radar_points": int(radar_pts.shape[0]),
    }


def build_sweep_index(nusc: NuScenes) -> Dict[str, List[tuple]]:
    """预建雷达 sweep 索引：channel -> [(timestamp_s, sample_data_token), ...]（按时间排序）。

    避免每帧全量扫描 sample_data。
    """
    index: Dict[str, List[tuple]] = {ch: [] for ch in RADAR_CHANNELS}
    for sd in nusc.sample_data:
        if sd["is_key_frame"] or sd["channel"] not in RADAR_CHANNELS:
            continue
        index[sd["channel"]].append((sd["timestamp"] / 1e6, sd["token"]))
    for ch in index:
        index[ch].sort()
    return index


def radar_sweeps_in_key_ego(
    nusc: NuScenes, sample: dict, window_s: float = 0.3, sweep_index: Optional[Dict[str, List[tuple]]] = None
) -> np.ndarray:
    """累积关键帧 ±window 内的雷达 sweep 点，统一到关键帧 ego 坐标。

    返回 (N,4): x, y, z, rcs（rcs 用于置信度计算）。
    sweep_index: build_sweep_index() 的缓存，避免重复扫描。
    """
    import bisect

    t_key = sample["timestamp"] / 1e6
    key_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
    key_ep = nusc.get("ego_pose", key_sd["ego_pose_token"])
    qk = Quaternion(key_ep["rotation"])
    tk = np.asarray(key_ep["translation"], dtype=np.float64)
    if sweep_index is None:
        sweep_index = build_sweep_index(nusc)
    pts_list = []
    for ch in RADAR_CHANNELS:
        entries = sweep_index.get(ch, [])
        times = [e[0] for e in entries]
        lo = bisect.bisect_left(times, t_key - window_s)
        hi = bisect.bisect_right(times, t_key + window_s)
        for _, sd_token in entries[lo:hi]:
            sd = nusc.get("sample_data", sd_token)
            cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
            ep = nusc.get("ego_pose", sd["ego_pose_token"])
            pc = RadarPointCloud.from_file(os.path.join(nusc.dataroot, sd["filename"]))
            pts = pc.points.T
            if pts.shape[0] == 0:
                continue
            pts_ego = _radar_to_ego(pts[:, :3], cs)
            q = Quaternion(ep["rotation"])
            t = np.asarray(ep["translation"], dtype=np.float64)
            global_pts = (q.rotation_matrix @ pts_ego.T).T + t
            p_key = (qk.inverse.rotation_matrix @ (global_pts - tk).T).T
            pts_list.append(np.concatenate([p_key, pts[:, 5:6]], axis=1))  # x,y,z,rcs
    return np.concatenate(pts_list, axis=0) if pts_list else np.zeros((0, 4), np.float64)


def iter_frames(nusc: NuScenes, scene_name: Optional[str] = None, channel: str = "CAM_FRONT", limit: int = 50):
    """遍历帧（可按 scene 过滤）。"""
    scenes = nusc.scene
    if scene_name:
        scenes = [s for s in scenes if s["name"] == scene_name]
    n = 0
    for scene in scenes:
        sample_token = scene["first_sample_token"]
        while sample_token:
            sample = nusc.get("sample", sample_token)
            yield get_frame(nusc, sample, channel)
            n += 1
            if limit and n >= limit:
                return
            sample_token = sample["next"]
