# -*- coding: utf-8 -*-
"""VLM 定位输出协议：prompt 构造、0-999 相对坐标 token、解析与后处理。

对齐 Rex-Omni 风格输出序列：
<|object ref start|>person<|object ref end|><|box start|>123 245 456 678<|box end|>
其中框坐标是 4 个 0-999 的相对坐标 token（x0, y0, x1, y1），按图像宽高归一化。
"""
from __future__ import annotations

import json
import re
from typing import Dict, List, Optional, Sequence, Tuple

from metrics import iou

BoxTokens = Tuple[int, int, int, int]


def quantize_bbox(box_px: Sequence[float], width: int, height: int) -> BoxTokens:
    """像素框 -> 0-999 相对坐标 token。"""
    x0, y0, x1, y1 = box_px
    qx = lambda v, s: max(0, min(999, int(round(v / s * 999))))
    return (qx(x0, width), qx(y0, height), qx(x1, width), qx(y1, height))


def dequantize_bbox(tokens: Sequence[int], width: int, height: int) -> Tuple[float, float, float, float]:
    """0-999 相对坐标 token -> 像素框（可能越界，需后处理裁剪）。"""
    x0, y0, x1, y1 = tokens
    return (x0 / 999.0 * width, y0 / 999.0 * height, x1 / 999.0 * width, y1 / 999.0 * height)


def build_prompt(
    task: str,
    classes: Sequence[str],
    radar_roi: Optional[Sequence[float]] = None,
    style: str = "text",
) -> str:
    """构造文本 prompt 或雷达增强 prompt。

    radar_roi: [x0, y0, x1, y1] 像素坐标的雷达候选框；style='radar' 时写入指令。
    """
    cls_str = ", ".join(classes)
    if style == "text":
        return (
            f"Task: {task}\n"
            f"Detect the following target classes in this top-down drone-view image: {cls_str}.\n"
            "Respond ONLY with object reference + box tokens in the format:\n"
            "<|object ref start|>class<|object ref end|><|box start|>x0 y0 x1 y1<|box end|>\n"
            "where x0,y0,x1,y1 are integer relative coordinates in [0,999]."
        )
    if radar_roi is None:
        return build_prompt(task, classes, None, "text")
    rx0, ry0, rx1, ry1 = radar_roi
    return (
        f"Task: {task}\n"
        f"Radar sensor detected a candidate target region at image box [x0,y0,x1,y1]=[{rx0:.0f},{ry0:.0f},{rx1:.0f},{ry1:.0f}] (pixel coordinates).\n"
        f"Check this image; if the candidate region contains a target from: {cls_str}, output its box; otherwise output <|box start|>0 0 0 0<|box end|>.\n"
        "Respond ONLY in the format:\n"
        "<|object ref start|>class<|object ref end|><|box start|>x0 y0 x1 y1<|box end|>\n"
        "where coordinates are integer relative values in [0,999]."
    )


_BOX_PAT = re.compile(r"<\|box start\|>([^<]*?)<\|box end\|>", re.S)
_REF_PAT = re.compile(r"<\|object ref start\|>(.*?)<\|object ref end\|>", re.S)


def parse_boxes(text: str, width: int, height: int) -> List[Dict]:
    """解析模型输出文本，返回结构化目标框列表。"""
    results: List[Dict] = []
    for m in _BOX_PAT.finditer(text):
        nums = [int(float(v)) for v in re.findall(r"-?\d+\.?\d*", m.group(1))]
        if len(nums) != 4:
            continue
        tokens = tuple(max(0, min(999, n)) for n in nums)
        x0, y0, x1, y1 = dequantize_bbox(tokens, width, height)
        if x0 > x1:
            x0, x1 = x1, x0
        if y0 > y1:
            y0, y1 = y1, y0
        ref = ""
        pre = text[: m.start()]
        rm = list(_REF_PAT.finditer(pre))
        if rm:
            ref = rm[-1].group(1).strip()
        results.append(
            {
                "class_name": ref,
                "box_tokens": list(tokens),
                "box_px": [round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2)],
            }
        )
    return results


def nms(boxes: List[Dict], iou_thr: float = 0.7) -> List[Dict]:
    """按分数降序 NMS；boxes 元素需含 'box_px' 与可选 'score'。"""
    if not boxes:
        return []
    ordered = sorted(boxes, key=lambda b: b.get("score", 0.0), reverse=True)
    kept: List[Dict] = []
    for b in ordered:
        if any(iou(b["box_px"], k["box_px"]) >= iou_thr for k in kept):
            continue
        kept.append(b)
    return kept


def to_json(result: Dict) -> str:
    return json.dumps(result, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    W, H = 1920, 1080
    t = quantize_bbox((100, 200, 500, 600), W, H)
    assert all(0 <= v <= 999 for v in t)
    back = dequantize_bbox(t, W, H)
    assert abs(back[0] - 100) < 2 and abs(back[1] - 200) < 2 and abs(back[2] - 500) < 3 and abs(back[3] - 600) < 3

    text = (
        "<|object ref start|>drone<|object ref end|><|box start|>52 185 260 555<|box end|>"
        "<|object ref start|>drone<|object ref end|><|box start|>55 190 262 558<|box end|>"
    )
    parsed = parse_boxes(text, W, H)
    assert len(parsed) == 2 and parsed[0]["class_name"] == "drone"
    d = parse_boxes("<|box start|>0 0 0 0<|box end|>", W, H)
    assert len(d) == 1 and d[0]["box_px"] == [0.0, 0.0, 0.0, 0.0]

    kept = nms(parsed, 0.7)
    assert len(kept) == 1  # 两框重叠 > 0.99，NMS 留一个

    p1 = build_prompt("detect drones", ["drone", "bird"])
    p2 = build_prompt("detect drones", ["drone"], radar_roi=[100, 200, 500, 600], style="radar")
    assert "<|box start|>" in p1 and "Radar sensor" not in p1
    assert "Radar sensor" in p2 and "[100,200,500,600]" in p2.replace(" ", "")
    print("vlm_protocol self-test: all passed")
    print(to_json({"boxes": kept}))
