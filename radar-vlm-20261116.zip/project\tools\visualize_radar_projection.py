# -*- coding: utf-8 -*-
"""可视化：雷达点云投影到相机图像 + GT 框（论文第一张图的雏形）。

用法：
    python tools/visualize_radar_projection.py --dataroot data/nuScenes/v1.0-mini --out out/proj.png
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import get_frame, iter_frames, load_nuscenes  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes/v1.0-mini")
    ap.add_argument("--version", default="v1.0-mini")
    ap.add_argument("--out", default="out/radar_projection.png")
    ap.add_argument("--channel", default="CAM_FRONT")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, args.version)
    frame = next(iter_frames(nusc, channel=args.channel, limit=1))

    from PIL import Image, ImageDraw

    img = Image.open(frame["image_path"]).convert("RGB")
    draw = ImageDraw.Draw(img)
    W, H = frame["image_size"]

    # GT 框
    for b in frame["boxes_2d"]:
        x0, y0, x1, y1 = b["box_xyxy"]
        draw.rectangle([x0, y0, x1, y1], outline=(0, 255, 0), width=2)
        draw.text((x0 + 2, y0 + 2), f"{b['category']} {b['depth']:.0f}m", fill=(0, 255, 0))

    # 雷达点（投影，按深度着色：近红远蓝）
    pts = frame["radar_points_cam"]
    if pts.shape[0]:
        from nuscenes_loader import project_to_image, _global_to_cam  # noqa: F401
        K = np.asarray(frame["K"])
        depth = pts[:, 2]
        mask = depth > 0.5
        proj = project_to_image(pts[mask][:, :3], K)
        valid = (proj[:, 0] >= 0) & (proj[:, 0] < W) & (proj[:, 1] >= 0) & (proj[:, 1] < H) & (proj[:, 2] > 0.5)
        proj, d = proj[valid], depth[mask][valid]
        for (u, v, _), dd in zip(proj, d):
            r = int(255 * np.clip(1 - dd / 60.0, 0, 1))
            b = 255 - r
            draw.ellipse([u - 2, v - 2, u + 2, v + 2], fill=(r, 40, b))

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    img.save(args.out)
    print(f"saved {args.out}")
    print(f"frame: {frame['scene']} {frame['sample_token']} | "
          f"radar points {frame['n_radar_points']} | GT boxes {len(frame['boxes_2d'])}")


if __name__ == "__main__":
    main()
