#!/usr/bin/env bash
# SFT 启动脚本：单张 A100，nuScenes 数据（Rex-Omni 官方 finetuning 栈）
# 用法（在 finetuning 目录内执行）：
#   bash ../../scripts/sft_nuscenes_a100.sh
# 前提：已按 scripts/A100_SFT指南.md 安装好依赖（torch/transformers/flash-attn/deepspeed 等）

NNODES=1
GPUS_PER_NODE=1

export MASTER_ADDR=localhost
export MASTER_PORT=29500

run_name="rexomni_nuscenes_sft"

# 回到 finetuning 目录（脚本可能从别处调用）
cd "$(dirname "$0")/../../third_party/Rex-Omni/finetuning"

torchrun \
    --nnodes=${NNODES} \
    --nproc_per_node=${GPUS_PER_NODE} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    train.py \
    --config configs/sft_nuscenes.py \
    --deepspeed scripts/zero2.json \
    --data_flatten False \
    --tune_mm_vision False \
    --tune_mm_mlp True \
    --tune_mm_llm True \
    --bf16 \
    --output_dir work_dirs/sft_nuscenes \
    --num_train_epochs 1 \
    --per_device_train_batch_size 1 \
    --gradient_accumulation_steps 8 \
    --eval_strategy "no" \
    --save_strategy "steps" \
    --save_steps 500 \
    --save_total_limit 3 \
    --learning_rate 2e-5 \
    --mm_projector_lr 2e-5 \
    --optim adamw_torch \
    --warmup_ratio 0.03 \
    --weight_decay 0.01 \
    --max_grad_norm 1 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --model_max_length 4096 \
    --gradient_checkpointing True \
    --dataloader_num_workers 2 \
    --run_name ${run_name} \
    --report_to none
