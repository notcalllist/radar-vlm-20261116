# -*- coding: utf-8 -*-
"""E3 基线：雷达候选区域前景/背景分类（简化 PointNet）。

输入：每个候选的 128 点 (x,y,z,rcs) 点集；
输出：是否为有效目标（fg/bg）。

用法：
    python tools/train_pointnet_e3.py --epochs 40
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

RESULT = {"accuracy": 0.0}


class SimplePointNet(nn.Module):
    """简化 PointNet：逐点 MLP + 最大池化 + 分类头。"""

    def __init__(self, in_dim=4, hidden=64):
        super().__init__()
        self.enc = nn.Sequential(
            nn.Conv1d(in_dim, hidden, 1), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Conv1d(hidden, hidden * 2, 1), nn.BatchNorm1d(hidden * 2), nn.ReLU(),
            nn.Conv1d(hidden * 2, hidden * 4, 1), nn.BatchNorm1d(hidden * 4), nn.ReLU(),
        )
        self.head = nn.Sequential(
            nn.Linear(hidden * 4, hidden), nn.ReLU(), nn.Dropout(0.3), nn.Linear(hidden, 1)
        )

    def forward(self, x):  # (B, N, 4)
        x = x.transpose(1, 2)  # (B, 4, N)
        x = self.enc(x)
        x = torch.max(x, dim=2)[0]  # (B, C)
        return self.head(x).squeeze(-1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/e3_candidates.npz")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--out", default="experiments/e3_pointnet_baseline.json")
    args = ap.parse_args()

    d = np.load(args.data, allow_pickle=True)
    pts = d["points"].astype(np.float32)  # (N,128,4)
    labels = d["labels"].astype(np.float32)
    frames = d["frames"]
    print(f"samples={len(pts)} pos={int(labels.sum())} neg={int((1 - labels).sum())}")

    # 按帧划分，避免同帧泄漏
    uniq = sorted(set(frames.tolist()))
    rng = np.random.default_rng(0)
    order = rng.permutation(len(uniq))
    n_train = int(0.7 * len(uniq))
    n_val = int(0.15 * len(uniq))
    train_f = {uniq[i] for i in order[:n_train]}
    val_f = {uniq[i] for i in order[n_train:n_train + n_val]}
    test_f = {uniq[i] for i in order[n_train + n_val:]}

    def subset(fset):
        m = np.array([f in fset for f in frames])
        return torch.from_numpy(pts[m]), torch.from_numpy(labels[m])

    xtr, ytr = subset(train_f)
    xva, yva = subset(val_f)
    xte, yte = subset(test_f)
    print(f"train={len(xtr)} val={len(xva)} test={len(xte)}")

    # 特征标准化（用训练集统计）
    mean = xtr.reshape(-1, 4).mean(0, keepdim=True)
    std = xtr.reshape(-1, 4).std(0, keepdim=True).clamp_min(1e-6)
    xtr = (xtr - mean) / std
    xva = (xva - mean) / std
    xte = (xte - mean) / std

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device)
    model = SimplePointNet().to(device)
    pos_sum = float(ytr.sum())
    pos_weight = torch.tensor([(len(ytr) - pos_sum) / max(1.0, pos_sum)]).to(device)
    crit = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)

    n = len(xtr)
    best_val = -1
    for ep in range(args.epochs):
        model.train()
        perm = torch.randperm(n)
        tot_loss = 0.0
        for i in range(0, n, args.batch):
            idx = perm[i:i + args.batch]
            xb, yb = xtr[idx].to(device), ytr[idx].to(device)
            # 数据增强：抖动 + 随机丢点
            xb = xb + torch.randn_like(xb) * 0.02
            drop = (torch.rand(xb.shape[:2], device=xb.device) < 0.05).unsqueeze(-1)
            xb = xb.masked_fill(drop, 0.0)
            opt.zero_grad()
            loss = crit(model(xb), yb)
            loss.backward()
            opt.step()
            tot_loss += float(loss) * len(idx)
        # val
        model.eval()
        with torch.no_grad():
            pv = model(xva.to(device))
            acc = float(((pv > 0).float() == yva.to(device)).float().mean())
        if acc > best_val:
            best_val = acc
        if (ep + 1) % 10 == 0:
            print(f"ep {ep + 1}: loss={tot_loss / n:.4f} val_acc={acc:.3f}")

    # test
    model.eval()
    with torch.no_grad():
        pt = torch.sigmoid(model(xte.to(device))).cpu().numpy()
    yt = yte.numpy()
    pred = (pt > 0.5).astype(int)
    tp = int(((pred == 1) & (yt == 1)).sum())
    fp = int(((pred == 1) & (yt == 0)).sum())
    fn = int(((pred == 0) & (yt == 1)).sum())
    prec = tp / max(1, tp + fp)
    rec = tp / max(1, tp + fn)
    f1 = 2 * prec * rec / max(1e-9, prec + rec)
    acc = float((pred == yt).mean())
    result = {
        "model": "SimplePointNet",
        "samples": int(len(pts)),
        "train": int(len(xtr)),
        "val": int(len(xva)),
        "test": int(len(xte)),
        "test_accuracy": round(acc, 3),
        "test_precision": round(prec, 3),
        "test_recall": round(rec, 3),
        "test_f1": round(f1, 3),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    torch.save(model.state_dict(), "data/e3_pointnet_baseline.pt")
    print("saved model + results")


if __name__ == "__main__":
    main()
