# -*- coding: utf-8 -*-
"""雷达候选区域（RoI）生成与覆盖率评估。

思路（v1，图像平面版本）：
1. 雷达点云投影到相机图像平面；
2. 在图像平面做 DBSCAN 聚类（2D 点，单位像素）；
3. 每个簇取外接框并按深度扩张；
4. 计算置信度（点数、平均 RCS、距离衰减）；
5. 用 GT 框评估覆盖率（E2 指标）。

后续可扩展：BEV 聚类 + 凸包、多帧累积。
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from metrics import iou


# ---------- 轻量 DBSCAN（不依赖 sklearn） ----------
def dbscan(points: np.ndarray, eps: float = 40.0, min_samples: int = 2) -> np.ndarray:
    """返回每个点的簇标签（-1 为噪声）。points: (N,2)。"""
    n = len(points)
    labels = -np.ones(n, dtype=np.int64)
    if n == 0:
        return labels
    visited = np.zeros(n, dtype=bool)
    cluster_id = 0
    for i in range(n):
        if visited[i]:
            continue
        visited[i] = True
        neigh = _neighbors(points, i, eps)
        if len(neigh) < min_samples:
            labels[i] = -1
            continue
        labels[i] = cluster_id
        seeds = list(neigh)
        k = 0
        while k < len(seeds):
            j = seeds[k]
            k += 1
            if not visited[j]:
                visited[j] = True
                n2 = _neighbors(points, j, eps)
                if len(n2) >= min_samples:
                    seeds.extend([q for q in n2 if q not in seeds])
            if labels[j] == -1:
                labels[j] = cluster_id
        cluster_id += 1
    return labels


def _neighbors(points: np.ndarray, idx: int, eps: float) -> List[int]:
    d = np.linalg.norm(points - points[idx], axis=1)
    return [int(j) for j in np.where(d <= eps)[0]]


# ---------- RoI 生成 ----------
def generate_rois(
    points_cam: np.ndarray,
    K: np.ndarray,
    image_size: Tuple[int, int],
    eps_px: float = 40.0,
    min_samples: int = 2,
    expand: float = 1.6,
    max_rois: int = 10,
    min_depth: float = 2.0,
    max_depth: float = 80.0,
) -> List[Dict]:
    """由相机坐标系下的雷达点生成图像平面 RoI 列表。"""
    W, H = image_size
    if points_cam.shape[0] == 0:
        return []
    xyz = points_cam[:, :3]
    z = xyz[:, 2]
    mask = (z > min_depth) & (z < max_depth) & (np.abs(xyz[:, 0]) < z * 2.5)  # 约 68° 视场裁剪
    xyz, z = xyz[mask], z[mask]
    if xyz.shape[0] < min_samples:
        return []
    rcs = points_cam[mask, 3] if points_cam.shape[1] > 3 else np.ones(len(xyz))
    uvw = (K @ xyz.T).T
    uv = uvw[:, :2] / np.where(np.abs(uvw[:, 2:3]) < 1e-9, 1e-9, uvw[:, 2:3])
    in_img = (uv[:, 0] >= 0) & (uv[:, 0] < W) & (uv[:, 1] >= 0) & (uv[:, 1] < H)
    uv, z_keep, rcs = uv[in_img], z[in_img], rcs[in_img]
    if len(uv) < min_samples:
        return []

    labels = dbscan(uv.astype(np.float64), eps=eps_px, min_samples=min_samples)
    rois: List[Dict] = []
    for cid in sorted(set(labels)):
        if cid == -1:
            continue
        sel = labels == cid
        pts = uv[sel]
        depth = float(np.median(z_keep[sel]))
        cx, cy = pts.mean(axis=0)
        half = max(pts.max(axis=0) - pts.min(axis=0)) / 2 + 6.0
        half *= expand
        x0, y0 = cx - half, cy - half
        x1, y1 = cx + half, cy + half
        x0, y0 = max(0, x0), max(0, y0)
        x1, y1 = min(W - 1, x1), min(H - 1, y1)
        n_pts = int(sel.sum())
        conf = (min(n_pts / 10.0, 1.0) * 0.5
                + min(float(np.clip(rcs[sel].mean(), 0, 30)) / 30.0, 1.0) * 0.3
                + float(np.clip(1 - depth / 80.0, 0, 1)) * 0.2)
        rois.append(
            {
                "box_xyxy": [round(float(x0), 1), round(float(y0), 1), round(float(x1), 1), round(float(y1), 1)],
                "depth": round(depth, 2),
                "conf": round(conf, 3),
                "n_points": n_pts,
            }
        )
    rois.sort(key=lambda r: -r["conf"])
    return rois[:max_rois]


def generate_rois_bev(
    points_ego: np.ndarray,
    points_cam: np.ndarray,
    K: np.ndarray,
    image_size: Tuple[int, int],
    dyn_filter: bool = True,
    eps_m: float = 1.2,
    min_samples: int = 2,
    expand: float = 1.15,
    min_px: float = 10.0,
    max_rois: int = 10,
    min_depth: float = 3.0,
    max_depth: float = 80.0,
    max_range: float = 70.0,
) -> List[Dict]:
    """BEV 聚类版 RoI 生成：

    1. 按动态属性过滤（1=动态, 2=潜在动态），剔除静态杂波；
    2. 在 ego 俯视平面 DBSCAN 聚类（单位：米）；
    3. 簇内点投影到图像，取投影点外接框并扩张。
    """
    W, H = image_size
    n = len(points_ego)
    if n < min_samples or len(points_cam) != n:
        return []
    xyz = points_ego[:, :3]
    rcs = points_ego[:, 3]
    dyn = points_ego[:, 5].astype(int)
    dist = np.linalg.norm(xyz[:, :2], axis=1)
    mask = (dist > 3.0) & (dist < max_range)
    if dyn_filter:
        mask &= np.isin(dyn, [1, 2])
    if mask.sum() < min_samples:
        return []
    labels = dbscan(xyz[mask][:, :2], eps=eps_m, min_samples=min_samples)
    rois: List[Dict] = []
    for cid in sorted(set(labels)):
        if cid == -1:
            continue
        sel = np.where(mask)[0][labels == cid]
        pts_cam = points_cam[sel, :3]
        z = pts_cam[:, 2]
        vis = (z > min_depth) & (z < max_depth)
        if vis.sum() < 2:
            continue
        uvw = (K @ pts_cam[vis].T).T
        u = uvw[:, 0] / np.where(np.abs(uvw[:, 2]) < 1e-9, 1e-9, uvw[:, 2])
        v = uvw[:, 1] / np.where(np.abs(uvw[:, 2]) < 1e-9, 1e-9, uvw[:, 2])
        in_img = (u >= 0) & (u < W) & (v >= 0) & (v < H)
        if in_img.sum() < 2:
            continue
        uu, vv = u[in_img], v[in_img]
        x0, y0, x1, y1 = uu.min(), vv.min(), uu.max(), vv.max()
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        half_w = max((x1 - x0) / 2 * expand, min_px / 2)
        half_h = max((y1 - y0) / 2 * expand, min_px / 2)
        x0, y0 = max(0, cx - half_w), max(0, cy - half_h)
        x1, y1 = min(W - 1, cx + half_w), min(H - 1, cy + half_h)
        depth = float(np.median(z[vis]))
        n_pts = int(len(sel))
        conf = (
            min(n_pts / 6.0, 1.0) * 0.5
            + min(float(np.clip(rcs[sel].mean(), 0, 30)) / 30.0, 1.0) * 0.3
            + float(np.clip(1 - depth / 80.0, 0, 1)) * 0.2
        )
        rois.append(
            {
                "box_xyxy": [round(float(x0), 1), round(float(y0), 1), round(float(x1), 1), round(float(y1), 1)],
                "depth": round(depth, 2),
                "conf": round(conf, 3),
                "n_points": n_pts,
            }
        )
    rois.sort(key=lambda r: -r["conf"])
    return rois[:max_rois]


def generate_rois_heatmap(
    points_cam: np.ndarray,
    K: np.ndarray,
    image_size: Tuple[int, int],
    cell: int = 40,
    min_pts: int = 3,
    max_rois: int = 15,
    expand: float = 2.0,
    obj_size_m: float = 2.5,
    min_depth: float = 3.0,
    max_depth: float = 80.0,
) -> List[Dict]:
    """雷达点密度热图版 RoI：统计投影点密度，峰值单元格生成深度自适应框。

    相比聚类版更稳定：稀疏点云不会被 DBSCAN 拆成噪声，也不会因聚类链式合并
    成大块背景。
    """
    W, H = image_size
    if len(points_cam) == 0:
        return []
    z = points_cam[:, 2]
    vis = (z > min_depth) & (z < max_depth)
    if vis.sum() < min_pts:
        return []
    pts = points_cam[vis, :3]
    d = z[vis]
    uvw = (K @ pts.T).T
    u = uvw[:, 0] / uvw[:, 2]
    v = uvw[:, 1] / uvw[:, 2]
    inimg = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    u, v, d = u[inimg], v[inimg], d[inimg]
    if len(u) < min_pts:
        return []
    cells = np.stack([np.floor(u / cell), np.floor(v / cell)], axis=1).astype(np.int64)
    uniq, inv, counts = np.unique(cells, axis=0, return_inverse=True, return_counts=True)
    f = 0.5 * (K[0, 0] + K[1, 1])
    rois = []
    for i, (cu, cv) in enumerate(uniq):
        if counts[i] < min_pts:
            continue
        sel = inv == i
        cx = (cu + 0.5) * cell
        cy = (cv + 0.5) * cell
        depth = float(np.median(d[sel]))
        half = max(0.5 * f * obj_size_m / max(depth, 1.0), cell / 2.0) * expand
        x0, y0 = max(0.0, cx - half), max(0.0, cy - half)
        x1, y1 = min(W - 1.0, cx + half), min(H - 1.0, cy + half)
        conf = min(counts[i] / 10.0, 1.0) * 0.6 + float(np.clip(1 - depth / 80.0, 0, 1)) * 0.4
        rois.append(
            {
                "box_xyxy": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)],
                "depth": round(depth, 2),
                "conf": round(conf, 3),
                "n_points": int(counts[i]),
            }
        )
    rois.sort(key=lambda r: -r["conf"])
    return rois[:max_rois]


# ---------- 覆盖率评估 ----------
def roi_covers_gt(roi_box: Sequence[float], gt_box: Sequence[float], min_cover: float = 0.5) -> bool:
    """GT 框被 RoI 覆盖的比例（交集 / GT 面积）。"""
    x0, y0, x1, y1 = gt_box
    ix0, iy0 = max(x0, roi_box[0]), max(y0, roi_box[1])
    ix1, iy1 = min(x1, roi_box[2]), min(y1, roi_box[3])
    inter = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
    gt_area = max(1e-9, (x1 - x0) * (y1 - y0))
    return (inter / gt_area) >= min_cover


def evaluate_rois(
    rois: List[Dict],
    gt_boxes: List[Dict],
    min_cover: float = 0.5,
    iou_thr: float = 0.3,
) -> Dict:
    """统计：覆盖率、Recall@K、虚警 RoI 数。"""
    if not gt_boxes:
        return {"n_gt": 0, "coverage": 0.0, "recall_at_k": 0.0, "false_alarm_rois": len(rois)}
    covered = 0
    for gt in gt_boxes:
        gb = gt["box_xyxy"]
        if any(roi_covers_gt(r["box_xyxy"], gb, min_cover) for r in rois):
            covered += 1
    # 虚警：RoI 与所有 GT（按 IoU）都不重叠
    fa = 0
    for r in rois:
        if not any(iou(r["box_xyxy"], g["box_xyxy"]) >= iou_thr for g in gt_boxes):
            fa += 1
    return {
        "n_gt": len(gt_boxes),
        "coverage": round(covered / len(gt_boxes), 3),
        "recall_at_k": round(covered / len(gt_boxes), 3),
        "false_alarm_rois": fa,
    }


if __name__ == "__main__":
    # 合成自测：模拟 3 个目标附近的雷达点
    rng = np.random.default_rng(0)
    K = np.array([[800, 0, 640], [0, 800, 360], [0, 0, 1]], dtype=np.float64)
    pts = []
    for cx, cy, d in [(300, 200, 10), (900, 300, 20), (1100, 500, 30)]:
        z = d
        x = (cx - 640) * z / 800
        y = (cy - 360) * z / 800
        pts.append(np.c_[rng.normal([x, y, z], [0.3, 0.3, 0.2], size=(6, 3)), np.full(6, 15.0), np.zeros(6)])
    pts_cam = np.vstack(pts)
    rois = generate_rois(pts_cam, K, (1280, 720), eps_px=50, min_samples=2)
    assert len(rois) >= 1, "应至少生成一个 RoI"
    gt = [{"box_xyxy": [250, 150, 350, 250]}, {"box_xyxy": [850, 250, 950, 350]}]
    ev = evaluate_rois(rois, gt, min_cover=0.3)
    assert ev["n_gt"] == 2
    assert 0.0 <= ev["coverage"] <= 1.0
    print("radar_roi self-test passed:", {"n_rois": len(rois), **ev})
