# -*- coding: utf-8 -*-
"""L3 决策级融合：雷达候选 RoI 与 VLM 检测框的空间匹配、置信度路由与融合后处理。

流程：
1. 空间匹配：RoI 与 VLM 框按 IoU / 中心距配对；
2. 场景判定：根据图像亮度、模糊度、雷达点密度选择路由策略；
3. 融合输出：
   - 视觉路径：清晰场景、雷达弱 → 以 VLM 为主，雷达仅做一致性校验；
   - 雷达增强路径：低照/模糊/远距 → 雷达 RoI 约束 VLM 结果（扩大搜索、补漏）；
   - 联合路径：两者都可靠 → 融合置信度 + 一致性加权；
4. 后处理：带雷达一致性的 NMS。

本模块不依赖模型，可先用合成数据测试。
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from metrics import iou


# ---------- 场景判定 ----------
def scene_route(
    roi_conf: float,
    vlm_conf: float,
    brightness: float = 0.5,
    blur: float = 0.0,
    radar_density: float = 1.0,
) -> str:
    """返回 'vision' | 'radar' | 'joint'。

    brightness: 0-1（0 全黑）；blur: 0-1（1 全糊）；radar_density: 相对密度（1 正常）。
    """
    vision_reliable = brightness > 0.25 and blur < 0.5
    radar_reliable = radar_density > 0.3 and roi_conf > 0.4
    if vision_reliable and radar_reliable:
        return "joint"
    if vision_reliable and not radar_reliable:
        return "vision"
    if radar_reliable and not vision_reliable:
        return "radar"
    return "joint"  # 都不可靠时保守联合


# ---------- 匹配 ----------
def match(rois: Sequence[Dict], boxes: Sequence[Dict], iou_thr: float = 0.2, dist_thr: float = 80.0) -> List[Dict]:
    """一一匹配（贪心，按 IoU 降序）。返回 [{'roi': roi, 'box': box, 'iou': v}]。"""
    pairs: List[Tuple[float, int, int]] = []
    for i, r in enumerate(rois):
        for j, b in enumerate(boxes):
            v = iou(r["box_xyxy"], b["box_px"])
            if v >= iou_thr:
                pairs.append((v, i, j))
    pairs.sort(key=lambda t: -t[0])
    used_r, used_b = set(), set()
    out = []
    for v, i, j in pairs:
        if i in used_r or j in used_b:
            continue
        used_r.add(i)
        used_b.add(j)
        out.append({"roi": rois[i], "box": boxes[j], "iou": round(v, 3)})
    return out


# ---------- 融合 ----------
def fuse(
    rois: List[Dict],
    vlm_boxes: List[Dict],
    brightness: float = 0.5,
    blur: float = 0.0,
    radar_density: float = 1.0,
    route: Optional[str] = None,
    w_vision: float = 0.6,
    w_radar: float = 0.4,
    nms_iou: float = 0.6,
) -> Dict:
    """融合雷达 RoI 与 VLM 检测框，返回最终检测结果与路由标签。"""
    route = route or scene_route(
        max((r.get("conf", 0.0) for r in rois), default=0.0),
        max((b.get("score", 0.0) for b in vlm_boxes), default=0.0),
        brightness,
        blur,
        radar_density,
    )
    matched = match(rois, vlm_boxes)
    matched_box_ids = {id(p["box"]) for p in matched}
    matched_roi_ids = {id(p["roi"]) for p in matched}

    detections: List[Dict] = []
    for p in matched:
        b, r = p["box"], p["roi"]
        rc = r.get("conf", 0.0)
        bs = b.get("score", 1.0)
        if route == "vision":
            score = bs * 0.95
            src = "vlm"
        elif route == "radar":
            # 雷达约束：雷达 RoI 为准，VLM 提供类别；置信度按 RoI 置信度提权
            score = min(1.0, 0.4 * bs + 0.6 * rc + 0.05)
            src = "radar+vlm"
        else:  # joint：按 RoI 置信度分档融合（radar-boost）
            if rc >= 0.6:
                score = min(1.0, 0.45 * bs + 0.55 * rc + 0.08)
                src = "joint_boost"
            elif rc >= 0.4:
                score = min(1.0, 0.65 * bs + 0.35 * rc + 0.03)
                src = "joint"
            else:
                score = bs * 0.95
                src = "vlm"
        # 框裁剪到图像范围由调用方保证；此处只记录
        detections.append(
            {
                "box_px": b["box_px"],
                "class_name": b.get("class_name", ""),
                "score": round(score, 3),
                "route": route,
                "source": src,
                "iou": p["iou"],
            }
        )

    # 雷达有、视觉无：radar-only 候选（低置信标记）
    if route in ("radar", "joint"):
        for r in rois:
            if id(r) in matched_roi_ids:
                continue
            detections.append(
                {
                    "box_px": r["box_xyxy"],
                    "class_name": "",
                    "score": round(0.45 * r.get("conf", 0.5), 3),
                    "route": route,
                    "source": "radar_only",
                }
            )

    # 视觉有、雷达无：视觉框保留但按路由降权
    for b in vlm_boxes:
        if id(b) in matched_box_ids:
            continue
        detections.append(
            {
                "box_px": b["box_px"],
                "class_name": b.get("class_name", ""),
                "score": round(b.get("score", 1.0) * (0.75 if route == "radar" else 0.9), 3),
                "route": route,
                "source": "vlm_only",
            }
        )

    detections = _nms(detections, nms_iou)
    return {"route": route, "detections": detections}


def _nms(dets: List[Dict], iou_thr: float) -> List[Dict]:
    ordered = sorted(dets, key=lambda d: -d.get("score", 0.0))
    kept: List[Dict] = []
    for d in ordered:
        if any(iou(d["box_px"], k["box_px"]) >= iou_thr for k in kept):
            continue
        kept.append(d)
    return kept


if __name__ == "__main__":
    rois = [
        {"box_xyxy": [100, 100, 200, 200], "depth": 12.0, "conf": 0.8, "n_points": 20},
        {"box_xyxy": [400, 300, 480, 380], "depth": 25.0, "conf": 0.5, "n_points": 8},
    ]
    vlm_boxes = [
        {"box_px": [105, 105, 205, 205], "class_name": "car", "score": 1.0},
        {"box_px": [600, 500, 660, 560], "class_name": "pedestrian", "score": 1.0},  # 无雷达
    ]
    out = fuse(rois, vlm_boxes, brightness=0.2, blur=0.6, radar_density=1.0)
    assert out["route"] == "radar", out["route"]
    assert any(d["source"] == "radar_only" for d in out["detections"])
    out2 = fuse(rois, vlm_boxes, brightness=0.9, blur=0.0, radar_density=0.1)
    assert out2["route"] == "vision"
    out3 = fuse(rois, vlm_boxes, brightness=0.9, blur=0.0, radar_density=1.0)
    assert out3["route"] == "joint"
    print("fusion self-test passed:", {"route": out["route"], "n_det": len(out["detections"])})
