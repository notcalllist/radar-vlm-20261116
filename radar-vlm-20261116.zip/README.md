# 雷达-VLM 无人机目标感知 — 项目工作区总入口

> 硕士课题：基于雷达与视觉语言多模态融合的无人机目标感知方法研究（王洋俊，电子科大航空航天学院）
> 最后更新：2026-11-16 凌晨

## 🚀 快速开始

| 你想做什么 | 看这里 |
|---|---|
| 了解项目全貌 | [项目计划书.docx](项目计划书.docx) / [项目计划书.md](项目计划书.md) |
| 看最新进展（发组会） | [项目周报_2026-11-16.md](项目周报_2026-11-16.md) |
| 看实验结论 | [实验记录_E2.md](实验记录_E2.md)、[实验记录_E3.md](实验记录_E3.md)、[实验记录_E4.md](实验记录_E4.md)、[实验记录_E4b_E6.md](实验记录_E4b_E6.md) |
| 看论文稿 | [论文草稿/README.md](论文草稿/README.md) |
| 在 A100 上跑正式实验 | [scripts/A100迁移指南.md](scripts/A100迁移指南.md)、[scripts/a100_setup_and_eval.sh](scripts/a100_setup_and_eval.sh) |
| A100 服务器一键初始化（Clash 代理） | [scripts/a100_server_init.sh](scripts/a100_server_init.sh) |
| 可传输代码包（22.8MB） | [dist/radar-vlm-20261116.zip](dist/radar-vlm-20261116.zip) |
| 在 A100 上做 SFT 微调 | [scripts/A100_SFT指南.md](scripts/A100_SFT指南.md)、[scripts/sft_nuscenes_a100.sh](scripts/sft_nuscenes_a100.sh) |
| 技术方案细节 | [雷达与融合实施方案.md](雷达与融合实施方案.md) |

## 📁 目录结构

```
新建文件夹/
├── 项目计划书.docx / .md          # 正式计划书（给导师）
├── 项目周报_2026-11-16.md          # 周报（发组会）
├── 实验记录_E2/E3/E4/E4b_E6.md     # 实验日志
├── 雷达与融合实施方案.md            # 技术方案
├── 论文草稿/                        # 第1-7章 + figures/配图
├── project/                         # 代码
│   ├── src/   (nuscenes_loader, radar_roi, fusion, rex_infer, metrics, pointcloud, vlm_protocol)
│   └── tools/ (8 个实验脚本)
├── data/                            # nuScenes mini + SFT TSV + E3 数据集
├── models/                          # Rex-Omni 权重（全量 + AWQ）
├── third_party/Rex-Omni/            # Rex-Omni 源码
├── scripts/                         # A100 脚本 + 迁移指南
├── out/                             # 可视化与预测缓存
└── experiments/                     # 实验输出（json/csv）
```

## ✅ 已完成（截至 2026-11-16）

- 数据：nuScenes mini 下载解压；Rex-Omni 代码+权重（7.75GB）就绪
- 雷达模块：多帧累积(0.5s)+密度热图，候选覆盖率 **0.943**（30 帧）
- VLM：零样本 AP50 0.078、Recall 0.17（本地 8GB 跑通）
- 融合：L1/L2/L3 三档对比完成，L3 是唯一正向路线
- E3 基线：PointNet 候选分类 F1 0.579
- SFT 数据：150 帧 TSV（2091 框）生成并验证
- 论文：7 章骨架（2/3/4/5 章含真实实验数据）

## ⏳ 待办（等用户/导师输入）

1. **A100 大样本实验**：需要访问方式或服务器网络确认
2. **导师确认**：口径叙事、数据集选择、创新点表述
3. **SFT/GRPO 训练**：A100 上执行
4. **论文第 6 章填数 + 全文定稿**

## 🔑 关键数字备忘

| 指标 | 数值 |
|---|---|
| 单帧雷达点数 | ~197（97-323） |
| 每帧 GT 数 | 9.54（最大 28） |
| GT 框有雷达点占比（单帧） | 33% |
| 候选覆盖率（多帧+热图） | 0.847（340 帧全集） |
| 候选虚警率 | 73.2%（200 帧） |
| 激光雷达对比覆盖率 | 0.978（雷达 0.894，点数 14.5×） |
| 窗口最优 | 0.5s |
| VLM 零样本 AP50 | 0.078 |
| L3 融合 AP50（3帧） | 0.093（与基线持平） |
| PointNet 候选分类 F1 | 0.579 |
| 本地推理速度 | 20-30s/帧（8GB offload） |
