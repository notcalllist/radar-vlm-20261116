# -*- coding: utf-8 -*-
"""E2 参数扫描：BEV 聚类参数 × 动态过滤 × 覆盖率阈值。

用法：
    python tools/e2_sweep.py --limit 30
输出：控制台表格（eps, dyn, min_cover, coverage, mean_rois）
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import iter_frames, load_nuscenes  # noqa: E402
from radar_roi import evaluate_rois, generate_rois_bev  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=30)
    ap.add_argument("--min-samples", type=int, default=2)
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    frames = [f for f in iter_frames(nusc, limit=args.limit) if f["boxes_2d"]]
    print(f"loaded {len(frames)} frames with GT")

    combos = []
    for eps in (1.0, 1.5, 2.5, 4.0):
        for dyn in (True, False):
            for mc in (0.3, 0.5, 0.7):
                combos.append((eps, dyn, mc))

    results = []
    for eps, dyn, mc in combos:
        covs, n_rois = [], []
        for f in frames:
            rois = generate_rois_bev(
                f["radar_points_ego"], f["radar_points_cam"],
                np.asarray(f["K"]), tuple(f["image_size"]),
                dyn_filter=dyn, eps_m=eps, min_samples=args.min_samples,
            )
            ev = evaluate_rois(rois, f["boxes_2d"], min_cover=mc)
            covs.append(ev["coverage"])
            n_rois.append(len(rois))
        results.append((eps, dyn, mc, round(float(np.mean(covs)), 3), round(float(np.mean(n_rois)), 2)))

    print(f"{'eps':>5} {'dyn':>5} {'mcover':>6} {'coverage':>8} {'rois':>6}")
    for r in results:
        print(f"{r[0]:>5} {str(r[1]):>5} {r[2]:>6} {r[3]:>8} {r[4]:>6}")


if __name__ == "__main__":
    main()
