# -*- coding: utf-8 -*-
"""E4b：雷达引导的局部检测（L1 提示级融合的一种实现）。

流程：
1. 多帧累积雷达 + 密度热图生成 RoI（E2 方案）；
2. 对每个 RoI 裁剪图像（含 1.4 倍边距），送 Rex-Omni 局部检测；
3. 检测框坐标映射回原图；
4. 多 RoI 结果 NMS 合并；
5. 与全图零样本基线（E4）对比 AP50 / Recall。

用法：
    python tools/e4b_radar_hint.py --limit 3 --max-rois 4
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from metrics import average_precision, precision_recall  # noqa: E402
from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import generate_rois_heatmap  # noqa: E402
from rex_infer import detect_boxes, load_rex  # noqa: E402

CATEGORIES = ["car", "truck", "bus", "pedestrian", "motorcycle", "bicycle"]


def nms(boxes, iou_thr=0.6):
    from metrics import iou as _iou

    ordered = sorted(boxes, key=lambda b: -b.get("score", 1.0))
    kept = []
    for b in ordered:
        if any(_iou(b["box_px"], k["box_px"]) >= iou_thr for k in kept):
            continue
        kept.append(b)
    return kept


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=3)
    ap.add_argument("--max-rois", type=int, default=4)
    ap.add_argument("--margin", type=float, default=1.4)
    ap.add_argument("--max-pixels", type=int, default=704 * 704)
    ap.add_argument("--max-tokens", type=int, default=256)
    ap.add_argument("--out", default="experiments/e4b_radar_hint.csv")
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    rex = load_rex("models/Rex-Omni", backend="transformers",
                   max_tokens=args.max_tokens, max_pixels=args.max_pixels)

    rows = []
    for i, frame in enumerate(iter_frames(nusc, limit=args.limit)):
        if not frame["boxes_2d"]:
            continue
        sample = nusc.get("sample", frame["sample_token"])
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]

        # 1) 雷达 RoI
        ego = radar_sweeps_in_key_ego(nusc, sample, 0.3)
        cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
        cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
        cam_pts = _ego_to_cam(ego[:, :3], cam_cs) if len(ego) else np.zeros((0, 3))
        rois = generate_rois_heatmap(cam_pts, K, (W, H), cell=40, min_pts=3, max_rois=args.max_rois)

        # 2) 逐 RoI 裁剪检测
        img = Image.open(frame["image_path"]).convert("RGB")
        all_boxes = []
        for r in rois:
            x0, y0, x1, y1 = r["box_xyxy"]
            w, h = x1 - x0, y1 - y0
            mx, my = w * (args.margin - 1) / 2, h * (args.margin - 1) / 2
            cx0, cy0 = max(0, x0 - mx), max(0, y0 - my)
            cx1, cy1 = min(W, x1 + mx), min(H, y1 + my)
            if cx1 - cx0 < 20 or cy1 - cy0 < 20:
                continue
            crop = img.crop((int(cx0), int(cy0), int(cx1), int(cy1)))
            boxes = detect_boxes(rex, crop, CATEGORIES)
            for b in boxes:
                bx0, by0, bx1, by1 = b["box_px"]
                b["box_px"] = [round(bx0 + cx0, 1), round(by0 + cy0, 1),
                               round(bx1 + cx0, 1), round(by1 + cy0, 1)]
            all_boxes.extend(boxes)
        merged = nms(all_boxes)

        # 3) 全图零样本（对照）
        full_boxes = detect_boxes(rex, img, CATEGORIES)

        def evaluate(preds):
            pb = [p["box_px"] for p in preds]
            ps = [p["score"] for p in preds]
            gb = [g["box_xyxy"] for g in frame["boxes_2d"]]
            return (round(average_precision(pb, ps, gb, 0.5), 3),
                    round(precision_recall(pb, ps, gb, 0.5)[0], 3),
                    round(precision_recall(pb, ps, gb, 0.5)[1], 3))

        ap_full, p_full, r_full = evaluate(full_boxes)
        ap_hint, p_hint, r_hint = evaluate(merged)
        # 保存预测，供融合实验复用（避免重复跑慢速 VLM）
        os.makedirs("out/e4b_preds", exist_ok=True)
        with open(f"out/e4b_preds/{frame['sample_token']}.json", "w", encoding="utf-8") as f:
            json.dump(
                {
                    "frame": frame["sample_token"],
                    "image_path": frame["image_path"],
                    "rois": rois,
                    "full_boxes": full_boxes,
                    "hint_boxes": merged,
                    "gt_boxes": frame["boxes_2d"],
                },
                f,
                ensure_ascii=False,
            )
        rows.append({
            "frame": f"{frame['scene']}_{frame['sample_token'][:8]}",
            "n_gt": len(frame["boxes_2d"]),
            "n_rois": len(rois),
            "full_pred": len(full_boxes), "full_ap50": ap_full, "full_recall": r_full,
            "hint_pred": len(merged), "hint_ap50": ap_hint, "hint_recall": r_hint,
        })
        print(f"[{len(rows)}] gt={len(frame['boxes_2d'])} rois={len(rois)} | "
              f"full: pred={len(full_boxes)} AP={ap_full} R={r_full} | "
              f"hint: pred={len(merged)} AP={ap_hint} R={r_hint}", flush=True)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    summary = {
        "n_frames": len(rows),
        "full_ap50": round(float(np.mean([r["full_ap50"] for r in rows])), 3),
        "full_recall": round(float(np.mean([r["full_recall"] for r in rows])), 3),
        "hint_ap50": round(float(np.mean([r["hint_ap50"] for r in rows])), 3),
        "hint_recall": round(float(np.mean([r["hint_recall"] for r in rows])), 3),
    }
    with open(Path(args.out).with_suffix(".json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
