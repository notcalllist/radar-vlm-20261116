# -*- coding: utf-8 -*-
"""目标检测/定位评估指标工具库。

适用场景：无人机目标感知（雷达-VLM 融合）实验评估。
坐标约定：bbox 为 [x0, y0, x1, y1]（像素或归一化坐标均可，需前后一致）。
"""
from __future__ import annotations

from typing import Iterable, List, Sequence, Tuple

import numpy as np

Box = Sequence[float]


def iou(box_a: Box, box_b: Box) -> float:
    """计算两个 [x0,y0,x1,y1] 框的 IoU。"""
    ax0, ay0, ax1, ay1 = (float(v) for v in box_a)
    bx0, by0, bx1, by1 = (float(v) for v in box_b)
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    iw, ih = max(0.0, ix1 - ix0), max(0.0, iy1 - iy0)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, ax1 - ax0) * max(0.0, ay1 - ay0)
    area_b = max(0.0, bx1 - bx0) * max(0.0, by1 - by0)
    union = area_a + area_b - inter
    return float(inter / union) if union > 0 else 0.0


def center_distance(box_a: Box, box_b: Box) -> float:
    """两个框中心点的欧氏距离（像素）。"""
    acx, acy = (box_a[0] + box_a[2]) / 2.0, (box_a[1] + box_a[3]) / 2.0
    bcx, bcy = (box_b[0] + box_b[2]) / 2.0, (box_b[1] + box_b[3]) / 2.0
    return float(np.hypot(acx - bcx, acy - bcy))


def match_detections(
    pred_boxes: Sequence[Box],
    pred_scores: Sequence[float],
    gt_boxes: Sequence[Box],
    iou_thr: float = 0.5,
) -> Tuple[List[int], List[int], List[int]]:
    """贪心匹配预测框与 GT 框（按分数降序）。

    返回 (tp_pred_idx, fp_pred_idx, fn_gt_idx)。
    """
    if len(pred_boxes) != len(pred_scores):
        raise ValueError("pred_boxes 与 pred_scores 长度不一致")
    order = np.argsort(-np.asarray(pred_scores, dtype=float))
    gt_matched = [False] * len(gt_boxes)
    tp: List[int] = []
    fp: List[int] = []
    for pi in order:
        best_j, best_iou = -1, 0.0
        for j, gt in enumerate(gt_boxes):
            if gt_matched[j]:
                continue
            v = iou(pred_boxes[pi], gt)
            if v > best_iou:
                best_j, best_iou = j, v
        if best_j >= 0 and best_iou >= iou_thr:
            gt_matched[best_j] = True
            tp.append(int(pi))
        else:
            fp.append(int(pi))
    fn = [j for j, m in enumerate(gt_matched) if not m]
    return tp, fp, fn


def precision_recall(pred_boxes, pred_scores, gt_boxes, iou_thr=0.5) -> Tuple[float, float]:
    """单图/单样本的 precision、recall（帧级匹配后统计）。"""
    tp, fp, fn = match_detections(pred_boxes, pred_scores, gt_boxes, iou_thr)
    n_tp, n_fp, n_fn = len(tp), len(fp), len(fn)
    p = n_tp / (n_tp + n_fp) if (n_tp + n_fp) else 0.0
    r = n_tp / (n_tp + n_fn) if (n_tp + n_fn) else 0.0
    return p, r


def f1_score(p: float, r: float) -> float:
    return 2 * p * r / (p + r) if (p + r) > 0 else 0.0


def duplicate_rate(
    pred_boxes: Sequence[Box],
    pred_scores: Sequence[float],
    iou_thr: float = 0.8,
) -> float:
    """重复预测率：与更高分预测框 IoU 超过阈值的预测框占比。"""
    if not pred_boxes:
        return 0.0
    order = np.argsort(-np.asarray(pred_scores, dtype=float))
    kept: List[Box] = []
    dup = 0
    for pi in order:
        if any(iou(pred_boxes[pi], kb) >= iou_thr for kb in kept):
            dup += 1
        else:
            kept.append(pred_boxes[pi])
    return dup / float(len(pred_boxes))


def average_precision(
    pred_boxes: Sequence[Box],
    pred_scores: Sequence[float],
    gt_boxes: Sequence[Box],
    iou_thr: float = 0.5,
) -> float:
    """单类单样本 AP（面积插值法，VOC 风格）。"""
    n_gt = len(gt_boxes)
    if n_gt == 0 or len(pred_boxes) == 0:
        return 0.0
    order = np.argsort(-np.asarray(pred_scores, dtype=float))
    gt_matched = [False] * n_gt
    tp_flags: List[int] = []
    for pi in order:
        best_j, best_iou = -1, 0.0
        for j, gt in enumerate(gt_boxes):
            if gt_matched[j]:
                continue
            v = iou(pred_boxes[pi], gt)
            if v > best_iou:
                best_j, best_iou = j, v
        if best_j >= 0 and best_iou >= iou_thr:
            gt_matched[best_j] = True
            tp_flags.append(1)
        else:
            tp_flags.append(0)
    tp_cum = np.cumsum(tp_flags)
    fp_cum = np.cumsum([1 - f for f in tp_flags])
    prec = tp_cum / (tp_cum + fp_cum + 1e-12)
    rec = tp_cum / n_gt
    # 面积插值 AP
    mrec = np.concatenate(([0.0], rec, [1.0]))
    mpre = np.concatenate(([1.0], prec, [0.0]))
    for i in range(len(mpre) - 2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i + 1])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))


def mean_ap(
    pred_list: Iterable[Tuple[Sequence[Box], Sequence[float], Sequence[Box]]],
    iou_thr: float = 0.5,
) -> float:
    """多样本 mAP@IoU（每个样本 (pred_boxes, pred_scores, gt_boxes)）。"""
    aps = [average_precision(pb, ps, gb, iou_thr) for pb, ps, gb in pred_list]
    return float(np.mean(aps)) if aps else 0.0


if __name__ == "__main__":
    # 简单自测
    a = [0, 0, 10, 10]
    assert abs(iou(a, a) - 1.0) < 1e-9
    assert abs(iou([0, 0, 10, 10], [10, 0, 20, 10]) - 0.0) < 1e-9
    assert abs(iou([0, 0, 10, 10], [5, 5, 15, 15]) - (25.0 / 175.0)) < 1e-9
    assert abs(center_distance([0, 0, 10, 10], [0, 10, 10, 20]) - 10.0) < 1e-9
    tp, fp, fn = match_detections([[0, 0, 10, 10], [50, 50, 60, 60]], [0.9, 0.8], [[0, 0, 10, 10]])
    assert tp == [0] and fp == [1] and fn == []
    p, r = precision_recall([[0, 0, 10, 10]], [0.9], [[0, 0, 10, 10]])
    assert p == 1.0 and r == 1.0
    assert abs(f1_score(1.0, 1.0) - 1.0) < 1e-9
    assert duplicate_rate([[0, 0, 10, 10], [0.5, 0.5, 10.5, 10.5]], [0.9, 0.8]) == 0.5
    ap = average_precision([[0, 0, 10, 10]], [0.9], [[0, 0, 10, 10]])
    assert abs(ap - 1.0) < 1e-9
    print("metrics self-test: all passed")
