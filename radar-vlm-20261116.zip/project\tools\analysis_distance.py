# -*- coding: utf-8 -*-
"""分析：VLM 检测能力随目标距离的变化（分桶统计）。

读取 out/e4b_preds/*.json（含 gt_boxes 的 distance 字段与全部预测框），
按距离分桶统计召回/精度，验证"远处小目标漏检严重"的假设。

用法：
    python tools/analysis_distance.py
"""
from __future__ import annotations

import glob
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from metrics import iou  # noqa: E402

BUCKETS = [(0, 10), (10, 20), (20, 30), (30, 50), (50, 200)]


def main():
    files = sorted(glob.glob("out/e4b_preds/*.json"))
    if not files:
        print("no cached predictions")
        return

    stats = {f"{a}-{b}m": {"n_gt": 0, "hit_full": 0, "hit_hint": 0} for a, b in BUCKETS}
    for fp in files:
        d = json.load(open(fp, encoding="utf-8"))
        for gt in d["gt_boxes"]:
            dist = gt.get("distance", 999)
            key = None
            for a, b in BUCKETS:
                if a <= dist < b:
                    key = f"{a}-{b}m"
                    break
            if key is None:
                continue
            stats[key]["n_gt"] += 1
            for preds, field in ((d["full_boxes"], "hit_full"), (d["hint_boxes"], "hit_hint")):
                if any(iou(p["box_px"], gt["box_xyxy"]) >= 0.5 for p in preds):
                    stats[key][field] += 1

    print(f"{'bucket':>10} {'n_gt':>5} {'recall_full':>11} {'recall_hint':>11}")
    summary = {}
    for a, b in BUCKETS:
        key = f"{a}-{b}m"
        s = stats[key]
        rf = s["hit_full"] / s["n_gt"] if s["n_gt"] else 0.0
        rh = s["hit_hint"] / s["n_gt"] if s["n_gt"] else 0.0
        summary[key] = {"n_gt": s["n_gt"], "recall_full": round(rf, 3), "recall_hint": round(rh, 3)}
        print(f"{key:>10} {s['n_gt']:>5} {rf:>11.3f} {rh:>11.3f}")

    Path("experiments/analysis_distance.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("saved experiments/analysis_distance.json")


if __name__ == "__main__":
    main()
