#!/usr/bin/env bash
# ============================================================
# A100 服务器一键初始化（数据 + 权重 + Python 环境 + 冒烟测试）
# 用法：
#   PROXY=http://127.0.0.1:7890 bash a100_server_init.sh
#   （Clash 默认 7890；如果你的 Clash 端口不同请修改 PROXY）
# 前提：代码包已解压到 ~/radar-vlm（包含 project/ scripts/ 等）
# ============================================================
set -e
WORK=${WORK:-$HOME/radar-vlm}
# 自动探测 Clash 代理端口（可用 PROXY 环境变量手动指定）
if [ -z "$PROXY" ]; then
  for p in 7890 7897 10809 1080 7891 8888; do
    if curl -s -o /dev/null --max-time 3 -x "http://127.0.0.1:$p" https://huggingface.co; then
      PROXY="http://127.0.0.1:$p"; break
    fi
  done
  PROXY=${PROXY:-http://127.0.0.1:7890}
fi
export http_proxy=$PROXY https_proxy=$PROXY HTTP_PROXY=$PROXY HTTPS_PROXY=$PROXY
export HF_ENDPOINT=https://hf-mirror.com

cd "$WORK"

echo "===== 0. 环境检查 ====="
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader || { echo "找不到 GPU"; exit 1; }
python3 --version
which git curl || { echo "缺少 git/curl"; exit 1; }
echo "proxy=$PROXY"

echo "===== 1. 数据目录 ====="
mkdir -p data/nuScenes data/visdrone models

echo "===== 2. 下载 nuScenes mini (3.9GB) ====="
if [ ! -f data/nuScenes/v1.0-mini.tgz ]; then
  curl -L --retry 3 -x "$PROXY" -o data/nuScenes/v1.0-mini.tgz \
    https://www.nuscenes.org/data/v1.0-mini.tgz
fi
if [ ! -d data/nuScenes/samples ]; then
  tar -xzf data/nuScenes/v1.0-mini.tgz -C data/nuScenes
fi
echo "nuScenes OK"

echo "===== 3. 下载 VisDrone (val + train) ====="
VBASE=https://github.com/ultralytics/assets/releases/download/v0.0.0
for f in VisDrone2019-DET-val.zip VisDrone2019-DET-train.zip; do
  if [ ! -f "data/visdrone/$f" ]; then
    curl -L --retry 3 -x "$PROXY" -o "data/visdrone/$f" "$VBASE/$f"
    unzip -q -o "data/visdrone/$f" -d data/visdrone
  fi
done
echo "VisDrone OK"

echo "===== 4. 下载 Rex-Omni 权重 (7.75GB) ====="
pip install -q huggingface_hub
python3 - <<'PY'
import os
from huggingface_hub import snapshot_download
if not os.path.exists("models/Rex-Omni/config.json"):
    snapshot_download("IDEA-Research/Rex-Omni", local_dir="models/Rex-Omni", max_workers=4)
    print("weights done")
else:
    print("weights exist, skip")
PY

echo "===== 5. Python 环境 ====="
if [ ! -d .venv ]; then python3 -m venv .venv; fi
source .venv/bin/activate
pip install -U pip -q
pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu124 -q
pip install transformers==4.51.3 accelerate==1.10.1 qwen_vl_utils==0.0.14 \
            nuscenes-devkit==1.2.0 pyquaternion pillow numpy matplotlib peft -q
if [ -d Rex-Omni ]; then pip install -e ./Rex-Omni --no-deps -q; fi
python -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())"

echo "===== 6. 冒烟测试（单帧雷达投影 + 单图推理）====="
python project/tools/visualize_radar_projection.py --dataroot data/nuScenes --out out/smoke.png
CUDA_VISIBLE_DEVICES=0 python - <<'PY'
import sys, time
sys.path.insert(0, "project/src")
from PIL import Image
from rex_infer import load_rex, detect_boxes
img = Image.open("data/visdrone/VisDrone2019-DET-val/images/" + __import__("os").listdir("data/visdrone/VisDrone2019-DET-val/images")[0]).convert("RGB")
rex = load_rex("models/Rex-Omni", max_tokens=128, max_pixels=495616)
t = time.time()
boxes = detect_boxes(rex, img, ["car", "pedestrian", "truck"])
print(f"inference {time.time()-t:.1f}s, {len(boxes)} boxes")
PY

echo "===== 7. DSH 安装提示 ====="
echo "DSH 请按官方方式安装；安装后启动时把工作目录设为 $WORK 即可。"
echo "===== DONE ====="
