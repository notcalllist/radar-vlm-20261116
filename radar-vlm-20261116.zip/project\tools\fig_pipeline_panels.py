# -*- coding: utf-8 -*-
"""生成雷达处理流程四联图：原图+GT / 雷达投影 / 密度热图+RoI / RoI 单独。

输出：out/fig_pipeline_4panel.png（论文/汇报用）
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes_loader import (  # noqa: E402
    _ego_to_cam,
    build_sweep_index,
    iter_frames,
    load_nuscenes,
    radar_sweeps_in_key_ego,
)
from radar_roi import generate_rois_heatmap  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--out", default="out/fig_pipeline_4panel.png")
    ap.add_argument("--window", type=float, default=0.5)
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    sweep_index = build_sweep_index(nusc)
    # 选一个目标较多的帧
    frame = None
    for f in iter_frames(nusc, limit=30):
        if len(f["boxes_2d"]) >= 15:
            frame = f
            break
    if frame is None:
        frame = next(iter_frames(nusc, limit=1))

    sample = nusc.get("sample", frame["sample_token"])
    K = np.asarray(frame["K"])
    W, H = frame["image_size"]
    img = np.asarray(Image.open(frame["image_path"]).convert("RGB"))

    ego = radar_sweeps_in_key_ego(nusc, sample, args.window, sweep_index)
    cam_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
    cam_cs = nusc.get("calibrated_sensor", cam_sd["calibrated_sensor_token"])
    cam_pts = _ego_to_cam(ego[:, :3], cam_cs) if len(ego) else np.zeros((0, 3))
    rois = generate_rois_heatmap(cam_pts, K, (W, H), cell=40, min_pts=3, max_rois=15)

    # 投影点
    vis = (cam_pts[:, 2] > 3) & (cam_pts[:, 2] < 80)
    pts = cam_pts[vis]
    uvw = (K @ pts.T).T
    u = uvw[:, 0] / uvw[:, 2]
    v = uvw[:, 1] / uvw[:, 2]
    m = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    u, v, d = u[m], v[m], pts[m, 2]
    # 单帧点（对比）
    single_pts = frame["radar_points_cam"]
    sv = (single_pts[:, 2] > 3) & (single_pts[:, 2] < 80)
    suvw = (K @ single_pts[sv][:, :3].T).T
    su = suvw[:, 0] / suvw[:, 2]
    svv = suvw[:, 1] / suvw[:, 2]
    sm = (su >= 0) & (su < W) & (svv >= 0) & (svv < H)

    fig, axes = plt.subplots(2, 2, figsize=(16, 9), dpi=110)
    for ax in axes.ravel():
        ax.axis("off")

    # (a) 原图 + GT
    ax = axes[0, 0]
    ax.imshow(img)
    for b in frame["boxes_2d"]:
        x0, y0, x1, y1 = b["box_xyxy"]
        ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec="lime", lw=1.5))
    ax.set_title(f"(a) Camera image + GT boxes ({len(frame['boxes_2d'])} objects)", fontsize=12)

    # (b) 单帧雷达点投影
    ax = axes[0, 1]
    ax.imshow(img)
    ax.scatter(su[sm], svv[sm], s=6, c="orange", alpha=0.9, label="single frame")
    ax.set_title(f"(b) Single-frame radar points projected ({int(sm.sum())} pts)", fontsize=12)

    # (c) 累积雷达点 + 深度着色
    ax = axes[1, 0]
    ax.imshow(img)
    sc = ax.scatter(u, v, s=6, c=d, cmap="jet_r", vmin=5, vmax=70)
    ax.set_title(f"(c) 0.5s accumulated radar points, colored by depth ({len(u)} pts)", fontsize=12)
    plt.colorbar(sc, ax=ax, fraction=0.03, pad=0.01, label="depth (m)")

    # (d) 热图 RoI
    ax = axes[1, 1]
    ax.imshow(img)
    for r in rois:
        x0, y0, x1, y1 = r["box_xyxy"]
        ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec="red", lw=2))
        ax.text(x0 + 2, y0 + 12, f"{r['conf']:.2f}", color="red", fontsize=8)
    ax.set_title(f"(d) Density-heatmap RoIs ({len(rois)} candidates)", fontsize=12)

    fig.tight_layout()
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out, bbox_inches="tight")
    print(f"saved {args.out}")
    print(f"frame: {frame['scene']} {frame['sample_token'][:8]} | "
          f"single pts {int(sm.sum())} -> accumulated {len(u)} | RoIs {len(rois)} | GT {len(frame['boxes_2d'])}")


if __name__ == "__main__":
    main()
