# -*- coding: utf-8 -*-
"""E2b：多帧雷达累积对“雷达提示覆盖率”的提升验证。

指标：GT 框内至少包含 1 个投影雷达点的比例（radar hint coverage）。
对比：单帧 vs 多帧累积（窗口 ±0.3 s）。

用法：
    python tools/e2_multiframe.py --limit 30
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nuscenes.nuscenes import NuScenes
from nuscenes.utils.data_classes import RadarPointCloud
from pyquaternion import Quaternion

from nuscenes_loader import _ego_to_cam, _radar_to_ego, iter_frames, load_nuscenes  # noqa: E402

RADAR_CHANNELS = (
    "RADAR_FRONT", "RADAR_FRONT_LEFT", "RADAR_FRONT_RIGHT",
    "RADAR_BACK_LEFT", "RADAR_BACK_RIGHT",
)


def sweep_points_in_key_ego(nusc: NuScenes, sample: dict, window_s: float = 0.3) -> np.ndarray:
    """累积关键帧 ±window 内的雷达 sweep 点，统一到关键帧 ego 坐标。"""
    t_key = sample["timestamp"] / 1e6
    key_sd = nusc.get("sample_data", sample["data"]["CAM_FRONT"])
    key_ep = nusc.get("ego_pose", key_sd["ego_pose_token"])
    qk = Quaternion(key_ep["rotation"])
    tk = np.asarray(key_ep["translation"], dtype=np.float64)
    pts_list = []
    for sd in nusc.sample_data:
        if sd["is_key_frame"] or sd["channel"] not in RADAR_CHANNELS:
            continue
        if abs(sd["timestamp"] / 1e6 - t_key) > window_s:
            continue
        cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
        ep = nusc.get("ego_pose", sd["ego_pose_token"])
        pc = RadarPointCloud.from_file(os.path.join(nusc.dataroot, sd["filename"]))
        pts = pc.points.T
        if pts.shape[0] == 0:
            continue
        pts_ego = _radar_to_ego(pts[:, :3], cs)
        q = Quaternion(ep["rotation"])
        t = np.asarray(ep["translation"], dtype=np.float64)
        global_pts = (q.rotation_matrix @ pts_ego.T).T + t
        p_key = (qk.inverse.rotation_matrix @ (global_pts - tk).T).T
        pts_list.append(p_key)
    return np.concatenate(pts_list, axis=0) if pts_list else np.zeros((0, 3))


def hint_coverage(pts_cam: np.ndarray, K: np.ndarray, boxes, W: int, H: int) -> float:
    """GT 框内含 ≥1 个投影雷达点的比例。"""
    if not boxes:
        return 0.0
    if len(pts_cam) == 0:
        return 0.0
    z = pts_cam[:, 2]
    vis = z > 0.5
    if vis.sum() == 0:
        return 0.0
    pts = pts_cam[vis]
    uvw = (K @ pts.T).T
    u = uvw[:, 0] / uvw[:, 2]
    v = uvw[:, 1] / uvw[:, 2]
    in_img = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    u, v = u[in_img], v[in_img]
    if len(u) == 0:
        return 0.0
    covered = 0
    for b in boxes:
        x0, y0, x1, y1 = b["box_xyxy"]
        if np.any((u >= x0) & (u <= x1) & (v >= y0) & (v <= y1)):
            covered += 1
    return covered / len(boxes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataroot", default="data/nuScenes")
    ap.add_argument("--limit", type=int, default=30)
    ap.add_argument("--window", type=float, default=0.3)
    args = ap.parse_args()

    nusc = load_nuscenes(args.dataroot, "v1.0-mini")
    n = 0
    single_cov, multi_cov, n_pts_single, n_pts_multi = [], [], [], []
    for frame in iter_frames(nusc, limit=1000):
        if not frame["boxes_2d"]:
            continue
        if n >= args.limit:
            break
        K = np.asarray(frame["K"])
        W, H = frame["image_size"]
        sample = nusc.get("sample", frame["sample_token"])

        single_pts = frame["radar_points_cam"][:, :3]
        c1 = hint_coverage(single_pts, K, frame["boxes_2d"], W, H)

        cam_cs = nusc.get(
            "calibrated_sensor",
            nusc.get("sample_data", sample["data"]["CAM_FRONT"])["calibrated_sensor_token"],
        )
        ego_pts = sweep_points_in_key_ego(nusc, sample, args.window)
        cam_pts = _ego_to_cam(ego_pts, cam_cs) if len(ego_pts) else np.zeros((0, 3))
        c2 = hint_coverage(cam_pts, K, frame["boxes_2d"], W, H)

        single_cov.append(c1)
        multi_cov.append(c2)
        n_pts_single.append(len(single_pts))
        n_pts_multi.append(len(cam_pts))
        n += 1
        print(f"[{n}/{args.limit}] single {c1:.2f} ({len(single_pts)} pts) | "
              f"multi {c2:.2f} ({len(cam_pts)} pts)")

    print(f"\nframes: {len(single_cov)}")
    print(f"single-frame hint coverage : {np.mean(single_cov):.3f}  (avg {np.mean(n_pts_single):.0f} pts)")
    print(f"multi-frame  hint coverage : {np.mean(multi_cov):.3f}  (avg {np.mean(n_pts_multi):.0f} pts, window {args.window}s)")


if __name__ == "__main__":
    main()
