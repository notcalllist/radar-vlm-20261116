# -*- coding: utf-8 -*-
"""Rex-Omni 推理适配层：统一项目内的 VLM 调用接口。

本机（Windows）用 transformers 后端 + attn_implementation="sdpa"（跳过 flash-attn）。
A100（Linux）推荐 vllm 后端 + AWQ 量化。
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
from PIL import Image

# 项目内统一的检测类别（与 nuScenes GT 对齐）
DEFAULT_CATEGORIES = ["car", "truck", "bus", "pedestrian", "motorcycle", "bicycle"]


def load_rex(
    model_path: str,
    backend: str = "transformers",
    quantization: Optional[str] = None,
    max_tokens: int = 1024,
    **kwargs,
):
    """加载 Rex-Omni 包装器。

    Windows 本机示例：
        load_rex("models/Rex-Omni", attn_implementation="sdpa")
    A100 示例：
        load_rex("/root/radar-vlm/weights/Rex-Omni-AWQ", backend="vllm", quantization="awq")
    """
    from rex_omni import RexOmniWrapper

    defaults = dict(
        max_tokens=max_tokens,
        temperature=0.0,
        top_p=0.05,
        top_k=1,
        repetition_penalty=1.05,
    )
    if backend == "transformers":
        defaults["attn_implementation"] = kwargs.pop("attn_implementation", "sdpa")
        defaults["torch_dtype"] = kwargs.pop("torch_dtype", None) or "auto"
    defaults.update(kwargs)
    return RexOmniWrapper(
        model_path=model_path,
        backend=backend,
        quantization=quantization,
        **defaults,
    )


def detect_boxes(rex, image: Image.Image | str, categories: Sequence[str] | None = None) -> List[Dict]:
    """对单张图像做检测，返回统一的框列表。"""
    if isinstance(image, str):
        image = Image.open(image).convert("RGB")
    cats = list(categories or DEFAULT_CATEGORIES)
    results = rex.inference(images=image, task="detection", categories=cats)
    return parse_result(results[0])


def parse_result(result: Dict) -> List[Dict]:
    """把 Rex-Omni 的 extracted_predictions 转成 [{class_name, box_px, score}]。"""
    boxes: List[Dict] = []
    preds = result.get("extracted_predictions") or {}
    for cat, items in preds.items():
        for it in items or []:
            if not isinstance(it, dict) or it.get("type") != "box":
                continue
            coords = it.get("coords") or []
            if len(coords) != 4:
                continue
            x0, y0, x1, y1 = (float(v) for v in coords)
            boxes.append(
                {
                    "class_name": str(cat).strip().lower(),
                    "box_px": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)],
                    "score": 1.0,
                }
            )
    return boxes


def save_overlay(image_path: str | Path, boxes: List[Dict], out_path: str | Path, color=(255, 0, 0)):
    """把预测框画到图上保存。"""
    from PIL import ImageDraw

    img = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    for b in boxes:
        x0, y0, x1, y1 = b["box_px"]
        draw.rectangle([x0, y0, x1, y1], outline=color, width=3)
        label = f"{b['class_name']}"
        draw.text((x0 + 3, y0 + 3), label, fill=color)
    os.makedirs(os.path.dirname(str(out_path)), exist_ok=True)
    img.save(str(out_path))
    return str(out_path)
